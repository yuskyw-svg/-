"""
gui.py
Tkinter GUIモジュール。
文化祭食券抽選システムのメインウィンドウを構築する。
店舗最大30行、スクロール対応。
"""

import tkinter as tk
from tkinter import filedialog, messagebox
import csv
import os
import sys
import json
import urllib.request
import urllib.parse
import re
import zipfile

from data_loader import load_csv
from lottery import Shop, run_lottery, sync_results_from_files


class LotteryApp:
    """抽選アプリケーションのGUIクラス"""

    MAX_SHOPS = 30
    SHOP_LABELS = [chr(ord("A") + i) for i in range(MAX_SHOPS)]  # A〜AD

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("文化祭 食券抽選システム")
        self.root.geometry("780x820")
        self.root.resizable(True, True)

        self.students = None
        self.csv_path = None
        # PyInstaller exe時はexeのフォルダ、通常実行時はスクリプトのフォルダ
        if getattr(sys, 'frozen', False):
            # exeがあるフォルダ
            exe_dir = os.path.dirname(sys.executable)
            # もし'dist'フォルダ内にいるなら、一つ上の階層をベースとする
            if os.path.basename(exe_dir).lower() == "dist":
                self.base_dir = os.path.dirname(exe_dir)
            else:
                self.base_dir = exe_dir
        else:
            self.base_dir = os.path.dirname(os.path.abspath(__file__))

        self.config_path = os.path.join(self.base_dir, "config.json")
        self._load_config()

        self._build_ui()
        self._append_log(f"システム起動: ベースディレクトリ = {self.base_dir}\n")

    def _load_config(self):
        """設定ファイル config.json から設定をロードする"""
        self.config_data = {}
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    self.config_data = json.load(f)
            except Exception as e:
                print(f"Error loading config.json: {e}")

    def _save_config(self):
        """設定を config.json に保存する"""
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.config_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self._append_log(f"エラー: config.json の保存に失敗しました: {e}\n")

    def _build_ui(self):
        """UIを構築する"""
        # --- タイトル ---
        title_label = tk.Label(
            self.root,
            text="文化祭 食券抽選システム",
            font=("Segoe UI", 18, "bold"),
            pady=10,
        )
        title_label.pack()

        # --- CSV読み込みセクション ---
        csv_frame = tk.Frame(self.root, pady=5)
        csv_frame.pack(fill=tk.X, padx=10)

        self.csv_btn = tk.Button(
            csv_frame, text="CSV読み込み", command=self._load_csv, width=15
        )
        self.csv_btn.pack(side=tk.LEFT)

        self.csv_label = tk.Label(csv_frame, text="未読み込み", fg="gray")
        self.csv_label.pack(side=tk.LEFT, padx=10)

        # --- 店舗設定セクション（スクロール対応） ---
        shop_outer_frame = tk.LabelFrame(
            self.root, text="店舗設定（最大30店舗）", padx=10, pady=10
        )
        shop_outer_frame.pack(fill=tk.BOTH, padx=10, pady=5, expand=False)

        # 店舗CSV読み込みボタン
        shop_csv_frame = tk.Frame(shop_outer_frame)
        shop_csv_frame.pack(fill=tk.X, pady=(0, 5))

        self.shop_csv_btn = tk.Button(
            shop_csv_frame, text="店舗CSV読み込み", command=self._load_shop_csv, width=18
        )
        self.shop_csv_btn.pack(side=tk.LEFT)

        self.shop_csv_label = tk.Label(
            shop_csv_frame, text="CSV形式: クラス番号,食品名,食券枚数,価格", fg="gray", font=("Segoe UI", 9)
        )
        self.shop_csv_label.pack(side=tk.LEFT, padx=10)

        # Canvas + Scrollbar でスクロール
        canvas = tk.Canvas(shop_outer_frame, height=300)
        scrollbar = tk.Scrollbar(
            shop_outer_frame, orient=tk.VERTICAL, command=canvas.yview
        )
        self.shop_frame = tk.Frame(canvas)

        self.shop_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
        )

        canvas.create_window((0, 0), window=self.shop_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # マウスホイールでスクロール
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        # ヘッダー
        headers = ["店舗", "クラス番号", "食品名", "食券枚数", "価格"]
        col_widths = [4, 10, 18, 8, 8]
        for col, (header, w) in enumerate(zip(headers, col_widths)):
            lbl = tk.Label(
                self.shop_frame, text=header, font=("Segoe UI", 10, "bold"), width=w
            )
            lbl.grid(row=0, column=col, padx=3, pady=2)

        # 店舗入力行（30行）
        self.shop_entries = []
        for i in range(self.MAX_SHOPS):
            row = i + 1
            label = self.SHOP_LABELS[i]

            # 店舗ラベル
            name_lbl = tk.Label(self.shop_frame, text=label, width=4)
            name_lbl.grid(row=row, column=0, padx=3, pady=1)

            # クラス番号入力
            class_entry = tk.Entry(self.shop_frame, width=10)
            class_entry.grid(row=row, column=1, padx=3, pady=1)

            # 食品名入力
            store_name_entry = tk.Entry(self.shop_frame, width=18)
            store_name_entry.grid(row=row, column=2, padx=3, pady=1)

            # 食券枚数入力
            ticket_entry = tk.Entry(self.shop_frame, width=8)
            ticket_entry.grid(row=row, column=3, padx=3, pady=1)

            # 価格入力
            price_entry = tk.Entry(self.shop_frame, width=8)
            price_entry.grid(row=row, column=4, padx=3, pady=1)

            self.shop_entries.append(
                {
                    "label": label,
                    "class_entry": class_entry,
                    "store_name_entry": store_name_entry,
                    "ticket_entry": ticket_entry,
                    "price_entry": price_entry,
                }
            )

        # --- 抽選パラメータ設定セクション ---
        param_frame = tk.LabelFrame(
            self.root, text="抽選パラメータ設定", padx=10, pady=5
        )
        param_frame.pack(fill=tk.X, padx=10, pady=5)

        tk.Label(param_frame, text="初期探索制限（秒）:").pack(side=tk.LEFT, padx=5)
        self.time_limit_var = tk.StringVar(value="20")
        self.time_limit_entry = tk.Entry(param_frame, textvariable=self.time_limit_var, width=6)
        self.time_limit_entry.pack(side=tk.LEFT, padx=5)

        tk.Label(param_frame, text="局所探索回数（回）:").pack(side=tk.LEFT, padx=15)
        self.iterations_var = tk.StringVar(value="1000")
        self.iterations_entry = tk.Entry(param_frame, textvariable=self.iterations_var, width=8)
        self.iterations_entry.pack(side=tk.LEFT, padx=5)

        tk.Label(param_frame, text="有効希望順位（第N希望まで）:").pack(side=tk.LEFT, padx=15)
        self.max_wish_rank_var = tk.StringVar(value="7")
        self.max_wish_rank_entry = tk.Entry(param_frame, textvariable=self.max_wish_rank_var, width=4)
        self.max_wish_rank_entry.pack(side=tk.LEFT, padx=5)

        # --- 学校設定＆Webアプリパッケージ書き出し（coconala・他校用） ---
        export_frame = tk.LabelFrame(
            self.root, text="学校設定＆Webアプリ書き出し（coconala・他校用）", padx=10, pady=5
        )
        export_frame.pack(fill=tk.X, padx=10, pady=5)

        # 1行目: 学校名
        row1 = tk.Frame(export_frame)
        row1.pack(fill=tk.X, pady=2)
        tk.Label(row1, text="カスタマイズ学校名:", width=18, anchor="w").pack(side=tk.LEFT, padx=5)
        self.school_name_var = tk.StringVar(value="デモ高等学校")
        self.school_name_entry = tk.Entry(row1, textvariable=self.school_name_var, width=35)
        self.school_name_entry.pack(side=tk.LEFT, padx=5)

        # 2行目: パスワード設定 (管理者 / 一般閲覧)
        row2 = tk.Frame(export_frame)
        row2.pack(fill=tk.X, pady=2)
        tk.Label(row2, text="管理者パスワード:", width=18, anchor="w").pack(side=tk.LEFT, padx=5)
        self.admin_pass_var = tk.StringVar(value="admin123")
        self.admin_pass_entry = tk.Entry(row2, textvariable=self.admin_pass_var, width=15)
        self.admin_pass_entry.pack(side=tk.LEFT, padx=5)

        tk.Label(row2, text="一般閲覧パスワード:").pack(side=tk.LEFT, padx=10)
        self.view_pass_var = tk.StringVar(value="")
        self.view_pass_entry = tk.Entry(row2, textvariable=self.view_pass_var, width=15)
        self.view_pass_entry.pack(side=tk.LEFT, padx=5)

        # 3行目: クラス別パスワード (テキストエリア)
        row3 = tk.Frame(export_frame)
        row3.pack(fill=tk.X, pady=2)
        tk.Label(row3, text="クラス別パスワード:", width=18, anchor="nw").pack(side=tk.LEFT, padx=5, pady=2)
        
        self.class_pass_text = tk.Text(row3, width=35, height=4, font=("Segoe UI", 9))
        self.class_pass_text.pack(side=tk.LEFT, padx=5)
        default_class_pass = "3-A:test\n3-B:test\n3-C:test"
        self.class_pass_text.insert("1.0", default_class_pass)
        
        # 説明ラベル
        tk.Label(row3, text="書き方:\nクラス名:パスワード\n(1行に1クラス分を入力)", fg="gray", justify=tk.LEFT, font=("Segoe UI", 8)).pack(side=tk.LEFT, padx=10)

        # 4行目: エクスポートボタン
        row4 = tk.Frame(export_frame)
        row4.pack(fill=tk.X, pady=5)
        self.export_btn = tk.Button(
            row4, text="デプロイ用ZIPをエクスポート", command=self._export_zip_package, font=("Segoe UI", 9, "bold"), bg="#2196F3", fg="white"
        )
        self.export_btn.pack(side=tk.RIGHT, padx=5)

        # --- ボタンセクション ---
        btn_frame = tk.Frame(self.root)
        btn_frame.pack(pady=10)

        self.start_btn = tk.Button(
            btn_frame,
            text="抽選開始",
            command=self._start_lottery,
            width=15,
            font=("Segoe UI", 11, "bold"),
            state=tk.DISABLED,
        )
        self.start_btn.pack(side=tk.LEFT, padx=5)

        self.sync_btn = tk.Button(
            btn_frame,
            text="照会システム同期 (結果フォルダから)",
            command=self._sync_inquiry_system,
            width=30,
            font=("Segoe UI", 11),
            bg="#f0f0f0",
        )
        self.sync_btn.pack(side=tk.LEFT, padx=5)

        # --- クラウドAPI連携セクション ---
        api_frame = tk.LabelFrame(
            self.root, text="クラウドAPI連携（Googleスプレッドシート自動同期）", padx=10, pady=5
        )
        api_frame.pack(fill=tk.X, padx=10, pady=5)

        # 1行目: GAS Web App URL
        url_row = tk.Frame(api_frame)
        url_row.pack(fill=tk.X, pady=2)
        tk.Label(url_row, text="GASウェブアプリURL:", width=18, anchor="w").pack(side=tk.LEFT, padx=5)
        
        default_url = self.config_data.get("gas_url", "")
        self.gas_url_var = tk.StringVar(value=default_url)
        self.gas_url_entry = tk.Entry(url_row, textvariable=self.gas_url_var, width=55)
        self.gas_url_entry.pack(side=tk.LEFT, padx=5)

        # 2行目: パスワード＆アクションボタン
        act_row = tk.Frame(api_frame)
        act_row.pack(fill=tk.X, pady=4)
        
        tk.Label(act_row, text="API接続パスワード:", width=18, anchor="w").pack(side=tk.LEFT, padx=5)
        default_pass = self.config_data.get("admin_password", "")
        if not default_pass:
            default_pass = self.admin_pass_var.get()
        self.gas_pass_var = tk.StringVar(value=default_pass)
        self.gas_pass_entry = tk.Entry(act_row, textvariable=self.gas_pass_var, width=15, show="*")
        self.gas_pass_entry.pack(side=tk.LEFT, padx=5)

        # アクションボタン群
        self.api_setup_btn = tk.Button(
            act_row, text="1. スプレッドシート初期化", command=self._api_setup_system, font=("Segoe UI", 9), bg="#4CAF50", fg="white"
        )
        self.api_setup_btn.pack(side=tk.LEFT, padx=10)

        self.api_get_btn = tk.Button(
            act_row, text="2. 応募データ取得", command=self._api_get_responses, font=("Segoe UI", 9), bg="#FF9800", fg="white"
        )
        self.api_get_btn.pack(side=tk.LEFT, padx=5)

        self.api_sync_btn = tk.Button(
            act_row, text="3. 抽選結果を同期", command=self._api_upload_results, font=("Segoe UI", 9, "bold"), bg="#E91E63", fg="white"
        )
        self.api_sync_btn.pack(side=tk.LEFT, padx=5)

        # --- セパレータ ---
        sep = tk.Frame(self.root, height=2, bd=1, relief=tk.SUNKEN)
        sep.pack(fill=tk.X, padx=10, pady=5)

        # --- 抽選ログ表示 ---
        log_label = tk.Label(self.root, text="抽選ログ表示", font=("Segoe UI", 10, "bold"))
        log_label.pack()

        log_frame = tk.Frame(self.root)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.log_text = tk.Text(
            log_frame, wrap=tk.WORD, state=tk.DISABLED, font=("Segoe UI", 10)
        )
        log_scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scrollbar.set)

        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    def _load_shop_csv(self):
        """店舗設定CSVを読み込み、入力欄に反映する"""
        filepath = filedialog.askopenfilename(
            title="店舗設定CSVファイルを選択",
            filetypes=[("CSVファイル", "*.csv"), ("すべてのファイル", "*.*")],
        )
        if not filepath:
            return

        try:
            shop_rows = []
            with open(filepath, "r", encoding="utf-8-sig") as f:
                reader = csv.reader(f)
                header = next(reader)  # ヘッダー行をスキップ
                for row in reader:
                    if len(row) < 3:
                        continue
                    class_id = row[0].strip()
                    store_name = row[1].strip()
                    ticket_str = row[2].strip()
                    price_str = row[3].strip() if len(row) > 3 else "0"
                    if class_id and store_name and ticket_str:
                        shop_rows.append((class_id, store_name, ticket_str, price_str))

            if not shop_rows:
                messagebox.showwarning("警告", "有効な店舗データが見つかりませんでした。")
                return

            if len(shop_rows) > self.MAX_SHOPS:
                messagebox.showwarning(
                    "警告",
                    f"店舗数が上限({self.MAX_SHOPS})を超えています。\n"
                    f"先頭{self.MAX_SHOPS}店舗のみ読み込みます。",
                )
                shop_rows = shop_rows[: self.MAX_SHOPS]

            # 既存の入力をクリアして新しいデータを入力
            for entry in self.shop_entries:
                entry["class_entry"].delete(0, tk.END)
                entry["store_name_entry"].delete(0, tk.END)
                entry["ticket_entry"].delete(0, tk.END)
                entry["price_entry"].delete(0, tk.END)

            for i, (class_id, store_name, ticket_str, price_str) in enumerate(shop_rows):
                self.shop_entries[i]["class_entry"].insert(0, class_id)
                self.shop_entries[i]["store_name_entry"].insert(0, store_name)
                self.shop_entries[i]["ticket_entry"].insert(0, ticket_str)
                self.shop_entries[i]["price_entry"].insert(0, price_str)

            filename = os.path.basename(filepath)
            self.shop_csv_label.config(
                text=f"{filename} ({len(shop_rows)}店舗)", fg="black"
            )
            self._append_log(
                f"店舗CSV読み込み完了: {filename} ({len(shop_rows)}店舗)\n"
            )

        except Exception as e:
            messagebox.showerror("エラー", f"店舗CSV読み込みに失敗しました:\n{e}")

    def _load_csv(self):
        """CSVファイルを読み込む"""
        filepath = filedialog.askopenfilename(
            title="CSVファイルを選択",
            filetypes=[("CSVファイル", "*.csv"), ("すべてのファイル", "*.*")],
        )
        if not filepath:
            return

        try:
            self.students = load_csv(filepath)
            self.csv_path = filepath
            count = len(self.students)
            filename = os.path.basename(filepath)
            self.csv_label.config(text=f"{filename} ({count}人)", fg="black")
            self.start_btn.config(state=tk.NORMAL)
            self._append_log(f"CSV読み込み完了: {filename} ({count}人)\n")
        except Exception as e:
            messagebox.showerror("エラー", f"CSV読み込みに失敗しました:\n{e}")

    def _start_lottery(self):
        """抽選を開始する"""
        if self.students is None:
            messagebox.showwarning("警告", "先にCSVを読み込んでください。")
            return

        # 店舗設定を収集
        shops = []
        for entry in self.shop_entries:
            class_id = entry["class_entry"].get().strip()
            store_name = entry["store_name_entry"].get().strip()
            ticket_str = entry["ticket_entry"].get().strip()
            price_str = entry["price_entry"].get().strip()

            if not class_id and not store_name and not ticket_str and not price_str:
                continue  # 空行はスキップ

            if not class_id or not store_name or not ticket_str or not price_str:
                messagebox.showwarning(
                    "警告",
                    f"{entry['label']}店: 全ての項目（クラス・食品名・枚数・価格）を入力してください。",
                )
                return

            try:
                ticket_count = int(ticket_str)
                ticket_price = int(price_str)
                if ticket_count <= 0 or ticket_price < 0:
                    raise ValueError
            except ValueError:
                messagebox.showwarning(
                    "警告",
                    f"{entry['label']}店: 枚数と価格は正しい記数で入力してください。",
                )
                return

            shops.append(
                Shop(entry["label"], class_id, store_name, ticket_count, ticket_price)
            )

        if not shops:
            messagebox.showwarning("警告", "少なくとも1つの店舗を設定してください。")
            return

        # 同じクラスの店舗をまとめて表示
        class_groups = {}
        for s in shops:
            if s.class_id not in class_groups:
                class_groups[s.class_id] = []
            class_groups[s.class_id].append(s)

        shop_info_lines = []
        for cid in sorted(class_groups.keys()):
            items = class_groups[cid]
            names = ", ".join(f"{s.name}:{s.store_name}({s.ticket_count}枚)" for s in items)
            shop_info_lines.append(f"  クラス{cid}: {names}")

        shop_info = "\n".join(shop_info_lines)

        confirm = messagebox.askyesno(
            "確認",
            f"以下の設定で抽選を開始しますか？\n\n"
            f"生徒数: {len(self.students)}人\n"
            f"店舗数: {len(shops)}店\n\n"
            f"{shop_info}",
        )
        if not confirm:
            return

        # パラメータの取得
        try:
            max_time = float(self.time_limit_var.get().strip())
            iters = int(self.iterations_var.get().strip())
            max_wish_rank = int(self.max_wish_rank_var.get().strip())
            if max_time <= 0 or iters < 0 or max_wish_rank <= 0 or max_wish_rank > 7:
                raise ValueError
        except ValueError:
            messagebox.showwarning(
                "警告",
                "探索制限秒数、局所探索回数は正しい数値を、有効希望順位は1〜7の範囲で入力してください。"
            )
            return

        # 抽選実行
        try:
            self.log_text.config(state=tk.NORMAL)
            self.log_text.delete("1.0", tk.END)
            self.log_text.config(state=tk.DISABLED)
            
            log_text = run_lottery(
                shops, 
                self.students, 
                self.base_dir, 
                iterations=iters, 
                max_time_seconds=max_time, 
                max_valid_wish_rank=max_wish_rank,
                log_callback=self._append_log
            )
            self._append_log("\n--- 抽選完了 ---\n")
            self._append_log("結果: result/ フォルダに出力\n")
            self._append_log("ログ: log.txt に出力\n")
            messagebox.showinfo(
                "完了",
                "抽選が完了しました。\n結果はresult/フォルダに出力されました。",
            )
        except Exception as e:
            messagebox.showerror("エラー", f"抽選中にエラーが発生しました:\n{e}")

    def _sync_inquiry_system(self):
        """結果テキストファイルから照会システムデータを同期する"""
        if self.students is None:
            messagebox.showwarning("警告", "先に生徒CSVを読み込んでください（名前の照合に必要です）。")
            return

        # 店舗設定を収集（Shopオブジェクトが必要）
        shops = []
        for entry in self.shop_entries:
            class_id = entry["class_entry"].get().strip()
            store_name = entry["store_name_entry"].get().strip()
            ticket_str = entry["ticket_entry"].get().strip()
            price_str = entry["price_entry"].get().strip()

            if not class_id and not store_name and not ticket_str and not price_str:
                continue

            try:
                ticket_count = int(ticket_str) if ticket_str else 0
                ticket_price = int(price_str) if price_str else 0
                shops.append(
                    Shop(entry["label"], class_id, store_name, ticket_count, ticket_price)
                )
            except ValueError:
                continue

        if not shops:
            messagebox.showwarning("警告", "店舗設定が入力されていません。")
            return

        confirm = messagebox.askyesno(
            "確認",
            "result/ フォルダ内のテキストファイルをもとに、照会システム用データを同期しますか？\n"
            "※既存の results.json は上書きされます。"
        )
        if not confirm:
            return

        try:
            results_dir = os.path.join(self.base_dir, "result")
            count = sync_results_from_files(results_dir, shops, self.students, self.base_dir)
            self._append_log(f"照会システム同期完了: {count}人の当選データを処理しました。\n")
            messagebox.showinfo("完了", f"同期が完了しました（{count}人分）。\nresults.json が更新されました。")
        except Exception as e:
            messagebox.showerror("エラー", f"同期中にエラーが発生しました:\n{e}")

    def _append_log(self, text: str):
        """ログテキストエリアにテキストを追加する"""
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, text + "\n")
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)
        self.root.update_idletasks() # リアルタイム描画更新

    def _export_zip_package(self):
        """設定された学校名、パスワードに基づいてHTML/GSを置換し、デプロイ用ZIPをエクスポートする"""
        school_name = self.school_name_var.get().strip()
        if not school_name:
            messagebox.showwarning("警告", "学校名を入力してください。")
            return
            
        admin_password = self.admin_pass_var.get().strip()
        view_password = self.view_pass_var.get().strip()
        
        # クラス別パスワードをパースして JS オブジェクト文字列に変換
        class_pass_lines = self.class_pass_text.get("1.0", tk.END).strip().split('\n')
        class_pass_dict = {}
        for line in class_pass_lines:
            if not line.strip() or ":" not in line:
                continue
            parts = line.split(":", 1)
            c_name = parts[0].strip()
            c_pass = parts[1].strip()
            if c_name and c_pass:
                class_pass_dict[c_name] = c_pass
                
        # JS連想配列の文字列を構築
        js_pass_lines = []
        for c, p in class_pass_dict.items():
            js_pass_lines.append(f"            '{c}': '{p}',")
        new_class_passwords_body = "\n".join(js_pass_lines)
        
        filepath = filedialog.asksaveasfilename(
            title="デプロイ用ZIPパッケージの保存先を選択",
            initialfile=f"{school_name}_deploy_package.zip",
            filetypes=[("ZIPファイル", "*.zip")]
        )
        if not filepath:
            return
        
        gas_deploy_dir = os.path.join(self.base_dir, "gas_deploy")
        if not os.path.exists(gas_deploy_dir):
            messagebox.showerror("エラー", "gas_deploy フォルダが見つかりません。")
            return
            
        import re
        
        try:
            with zipfile.ZipFile(filepath, "w", zipfile.ZIP_DEFLATED) as zf:
                for filename in os.listdir(gas_deploy_dir):
                    src_path = os.path.join(gas_deploy_dir, filename)
                    if os.path.isfile(src_path):
                        # テキストファイルなら中身を読み込んで置換
                        if filename.endswith((".html", ".gs")):
                            try:
                                with open(src_path, "r", encoding="utf-8") as f:
                                    content = f.read()
                                    
                                # 1. 学校名置換
                                content = content.replace("デモ高等学校", school_name)
                                
                                # 2. Code.gs 内のデフォルト管理者・閲覧パスワードの置換
                                if filename == "Code.gs":
                                    content = re.sub(
                                        r'\["ADMIN_PASSWORD",\s*"[^"]*",', 
                                        f'["ADMIN_PASSWORD", "{admin_password}",', 
                                        content
                                    )
                                    content = re.sub(
                                        r'\["VIEW_PASSWORD",\s*"[^"]*",', 
                                        f'["VIEW_PASSWORD", "{view_password}",', 
                                        content
                                    )
                                    
                                # 3. HTML内の CLASS_PASSWORDS オブジェクトの置換
                                if filename in ["sales.html", "dashboard.html"]:
                                    # const CLASS_PASSWORDS = { ... }; のパターンを置換
                                    pattern = r"const\s+CLASS_PASSWORDS\s*=\s*\{[^}]*\};"
                                    replacement = f"const CLASS_PASSWORDS = {{\n{new_class_passwords_body}\n        }};"
                                    content = re.compile(pattern).sub(replacement, content)
                                    
                                zf.writestr(filename, content)
                            except Exception as read_err:
                                # UTF-8で読めないバイナリや別ファイルはそのままコピー
                                zf.write(src_path, filename)
                        else:
                            zf.write(src_path, filename)
                            
            messagebox.showinfo(
                "完了",
                f"「{school_name}」用にカスタマイズされたデプロイパッケージを以下の場所に書き出しました：\n\n{filepath}\n\nこのZIPファイルを解凍して、中のファイルをGoogle Apps Scriptにコピペすればセットアップ完了です！"
            )
        except Exception as e:
            messagebox.showerror("エラー", f"パッケージの書き出しに失敗しました：\n{e}")

    def _call_gas_api(self, action, data=None):
        """GAS APIを呼び出す共通関数"""
        url = self.gas_url_var.get().strip()
        password = self.gas_pass_var.get().strip()
        
        if not url:
            raise ValueError("GASウェブアプリURLが入力されていません。")
        
        # 設定を config.json に保存
        self.config_data["gas_url"] = url
        self.config_data["admin_password"] = password
        self._save_config()
        
        payload = {
            "action": action,
            "password": password,
            "data": data
        }
        
        req_data = json.dumps(payload).encode('utf-8')
        req = urllib.request.Request(
            url,
            data=req_data,
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        
        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                res_body = response.read().decode('utf-8')
                return json.loads(res_body)
        except Exception as e:
            raise RuntimeError(f"GASとの通信に失敗しました。URLが正しいか、デプロイが「全員」になっているか確認してください。\n詳細: {e}")

    def _api_setup_system(self):
        """スプレッドシートの初期設定と店舗データをGASに送信して初期化する"""
        school_name = self.school_name_var.get().strip()
        admin_password = self.admin_pass_var.get().strip()
        view_password = self.view_pass_var.get().strip()
        max_wishes_str = self.max_wish_rank_var.get().strip()
        
        if not school_name:
            messagebox.showwarning("警告", "学校名を入力してください。")
            return
            
        # 店舗設定を収集
        shops = []
        for entry in self.shop_entries:
            class_id = entry["class_entry"].get().strip()
            store_name = entry["store_name_entry"].get().strip()
            ticket_str = entry["ticket_entry"].get().strip()
            price_str = entry["price_entry"].get().strip()
            
            if not class_id and not store_name and not ticket_str and not price_str:
                continue
            
            try:
                ticket_count = int(ticket_str) if ticket_str else 0
                price = int(price_str) if price_str else 0
                shops.append({
                    "class_id": class_id,
                    "store_name": store_name,
                    "ticket_count": ticket_count,
                    "price": price,
                    "description": f"{class_id}の店舗"
                })
            except ValueError:
                continue
                
        # クラスパスワードをパース
        class_pass_lines = self.class_pass_text.get("1.0", tk.END).strip().split('\n')
        passwords = []
        for line in class_pass_lines:
            if not line.strip() or ":" not in line:
                continue
            parts = line.split(":", 1)
            c_name = parts[0].strip()
            c_pass = parts[1].strip()
            if c_name and c_pass:
                passwords.append({
                    "class_id": c_name,
                    "password": c_pass,
                    "description": f"{c_name}ログイン用"
                })
                
        # 送信データの構築
        setup_data = {
            "settings": {
                "SCHOOL_NAME": school_name,
                "ADMIN_PASSWORD": admin_password,
                "VIEW_PASSWORD": view_password,
                "MAX_WISHES": max_wishes_str
            },
            "shops": shops,
            "passwords": passwords
        }
        
        confirm = messagebox.askyesno(
            "初期化確認",
            "現在入力されている「学校名」「店舗設定」「クラスパスワード」を\n"
            "Googleスプレッドシートに送信して初期構築を行いますか？\n"
            "※スプレッドシート上の既存の設定データは上書きされます。"
        )
        if not confirm:
            return
            
        try:
            self._append_log("スプレッドシートの初期設定を送信中...\n")
            res = self._call_gas_api("setup", setup_data)
            if res.get("success"):
                self._append_log("✅ スプレッドシートの初期設定・店舗データの書き込みが完了しました！\n")
                messagebox.showinfo("完了", "Googleスプレッドシートの初期設定とシート構築が完了しました！")
            else:
                raise RuntimeError(res.get("error", "未知のエラーが発生しました。"))
        except Exception as e:
            self._append_log(f"❌ 初期設定送信エラー: {e}\n")
            messagebox.showerror("エラー", f"スプレッドシートの初期化に失敗しました:\n{e}")

    def _api_get_responses(self):
        """スプレッドシートからGoogleフォームの回答データを自動取得する"""
        confirm = messagebox.askyesno(
            "データ取得確認",
            "Googleスプレッドシートから現在の応募（回答）データをダウンロードしますか？"
        )
        if not confirm:
            return
            
        try:
            self._append_log("応募回答データをスプレッドシートから取得中...\n")
            res = self._call_gas_api("get_responses")
            if not res.get("success"):
                raise RuntimeError(res.get("error", "回答データの取得に失敗しました。"))
                
            raw_data = res.get("data")
            if not raw_data or len(raw_data) <= 1:
                messagebox.showwarning("警告", "スプレッドシートに有効な回答データがありません。フォームにテスト送信などを行ってから再度試してください。")
                return
                
            # ローカルの responses.csv に書き出す (BOM付きUTF-8)
            local_csv_path = os.path.join(self.base_dir, "responses.csv")
            with open(local_csv_path, "w", encoding="utf-8-sig", newline="") as f:
                writer = csv.writer(f)
                writer.writerows(raw_data)
                
            self._append_log("✅ 応募回答データを正常にダウンロードしました。\n")
            
            # 取得したデータをそのまま抽選対象としてロード
            self.students = load_csv(local_csv_path)
            self.csv_path = local_csv_path
            count = len(self.students)
            self.csv_label.config(text=f"クラウド同期 ({count}人)", fg="green")
            self.start_btn.config(state=tk.NORMAL)
            self._append_log(f"クラウドデータロード完了: {count}人の生徒情報を読み込みました。\n")
            
            messagebox.showinfo("完了", f"スプレッドシートから{count}人分の応募データを自動取得し、抽選対象に設定しました！")
        except Exception as e:
            self._append_log(f"❌ 回答データ取得エラー: {e}\n")
            messagebox.showerror("エラー", f"回答データの自動取得に失敗しました:\n{e}")

    def _api_upload_results(self):
        """抽選結果JSONをGoogleドライブ（スプレッドシートの親フォルダ）に自動同期する"""
        results_json_path = os.path.join(self.base_dir, "results.json")
        if not os.path.exists(results_json_path):
            messagebox.showwarning("警告", "抽選結果ファイル(results.json)が見つかりません。先に「抽選開始」を実行してください。")
            return
            
        confirm = messagebox.askyesno(
            "同期確認",
            "ローカルの抽選結果(results.json)をGoogleドライブにアップロードし、\n"
            "ウェブアプリ照会システムに同期しますか？"
        )
        if not confirm:
            return
            
        try:
            self._append_log("抽選結果(results.json)をアップロード中...\n")
            with open(results_json_path, "r", encoding="utf-8") as f:
                results_data = json.load(f)
                
            res = self._call_gas_api("upload_results", results_data)
            if res.get("success"):
                self._append_log("✅ 抽選結果のクラウド同期が完了しました！これで照会システムから結果を検索できます。\n")
                messagebox.showinfo("完了", "抽選結果の同期が正常に完了しました！")
            else:
                raise RuntimeError(res.get("error", "同期エラーが発生しました。"))
        except Exception as e:
            self._append_log(f"❌ クラウド同期エラー: {e}\n")
            messagebox.showerror("エラー", f"クラウド同期に失敗しました:\n{e}")

