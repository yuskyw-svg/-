/**
 * 文化祭 抽選希望調査フォーム 自動作成スクリプト (FormCreator.gs)
 * 
 * 【使い方】
 * 1. 新しいスプレッドシートを作成し、ローカルソフトから「スプレッドシート初期化」を実行して「店舗設定」シートを作成・入力します。
 * 2. ツールバーの「拡張機能」＞「Apps Script」を開きます。
 * 3. このファイル（FormCreator.gs）のコードをコピー＆ペーストして保存します。
 * 4. 画面上部で「createLotteryForm」関数を選択し、「実行」をクリックします。
 * 5. 初回実行時はGoogleアカウントへの権限承認ダイアログが出るので、許可（承認）してください。
 * 6. 実行完了後、画面下部の「ログ」に表示される【編集用URL】から作成されたフォームを確認できます。
 * 
 * 【⚠️ 超重要：フォーム回答データをスプレッドシートに紐付ける手順 ⚠️】
 * フォームが作成された後、以下の手順を必ず行ってください。これを行わないと、生徒の回答データがスプレッドシートに届きません。
 * 
 * 1. 実行ログに表示された【編集用URL】をクリックして、作成されたフォームの編集画面を開きます。
 * 2. 画面上部のメニューから「回答」タブをクリックします。
 * 3. 右上にある緑色の「スプレッドシートにリンク」アイコンをクリックします。
 * 4. 送信先として「既存のスプレッドシートを選択」を選び、この管理用スプレッドシートを指定して紐付けます。
 * 5. 紐付けが成功すると、スプレッドシート上に「フォームの回答 1」というシートが新しく自動生成され、生徒の回答がそこにリアルタイムで蓄積されるようになります。
 */

function createLotteryForm() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("店舗設定");
  if (!sheet) {
    // もし「店舗設定」シートがない場合は getSystemSettings() を呼んで自動生成を試みる
    try {
      getSystemSettings();
      sheet = ss.getSheetByName("店舗設定");
    } catch (e) {}
  }
  if (!sheet) {
    throw new Error("「店舗設定」シートが見つかりません。スプレッドシートに「店舗設定」という名前のシートを作成してください。");
  }
  
  // Settingsシートから最大希望数および生徒番号のカスタムバリデーション情報を取得
  var maxWishes = 7;
  var sidRegex = "^\\d{4}$";
  var sidHelp = "半角数字4桁で入力してください（例: 0012, 1234）。";
  
  try {
    var settings = getSystemSettings();
    if (settings) {
      if (settings["MAX_WISHES"]) {
        var val = parseInt(settings["MAX_WISHES"], 10);
        if (!isNaN(val) && val >= 1 && val <= 7) {
          maxWishes = val;
        }
      }
      if (settings["STUDENT_ID_REGEX"]) {
        sidRegex = settings["STUDENT_ID_REGEX"];
      }
      if (settings["STUDENT_ID_HELP"]) {
        sidHelp = settings["STUDENT_ID_HELP"];
      }
    }
  } catch (e) {
    // 設定取得関数がない、またはSettingsシートがない場合はデフォルト値を使用
  }
  var lastRow = sheet.getLastRow();
  
  if (lastRow <= 1) {
    throw new Error("スプレッドシートに店舗のデータが入力されていません。1行目はヘッダー、2行目以降にデータを入力してください。");
  }
  
  // 1. スプレッドシートから店舗データを読み込む
  // getDisplayValues() を使用することで、日付に自動変換されたクラス名（例: "3-1"）も表示通りの文字列として取得できます
  var displayValues = sheet.getRange(2, 1, lastRow - 1, 3).getDisplayValues();
  var choices = [];
  
  for (var i = 0; i < displayValues.length; i++) {
    var classId = displayValues[i][0].toString().trim();
    var storeName = displayValues[i][1].toString().trim();
    if (storeName) {
      // 選択肢には商品名（B列）のみを使用します
      choices.push(storeName);
    }
  }
  
  if (choices.length === 0) {
    throw new Error("有効な店舗データが見つかりませんでした。クラス名と食品名が正しく入力されているか確認してください。");
  }
  
  // 2. 新しい Google フォームを作成
  var formTitle = ss.getName().replace("（回答）", "") + " 希望調査フォーム";
  var form = FormApp.create(formTitle);
  form.setDescription("文化祭の食品販売に関する希望投票フォームです。\nお一人様1回のみ、希望するメニューを選択してください。");
  
  // 3. 生徒番号の質問を追加 (バリデーション付き)
  var sidItem = form.addTextItem();
  sidItem.setTitle("生徒番号")
         .setHelpText(sidHelp)
         .setRequired(true);
  
  // スプレッドシートの設定に基づいた正規表現バリデーション
  var sidValidation = FormApp.createTextValidation()
                             .requireTextMatchesPattern(sidRegex)
                             .setHelpText(sidHelp)
                             .build();
  sidItem.setValidation(sidValidation);
  
  // 4. 氏名の質問を追加
  form.addTextItem()
      .setTitle("氏名（フルネーム）")
      .setHelpText("名字と名前の間にスペースを入れずに入力してください（例: 山田太郎）。")
      .setRequired(true);
      
  // 5. 希望調査（設定された希望数までプルダウンで追加）
  for (var rank = 1; rank <= maxWishes; rank++) {
    var selectItem = form.addListItem();
    selectItem.setTitle("第" + rank + "希望")
              .setHelpText("希望するメニューを選択してください（希望しない場合は未選択のままで構いません）。")
              .setRequired(rank === 1) // 第1希望のみ回答を必須にする
              .setChoiceValues(choices);
  }
  
  // 6. フォームの設定（セキュリティと制限）
  form.setLimitOneResponsePerUser(true); // 1ユーザーにつき回答1回制限
  
  // ログに出力
  Logger.log("==========================================================");
  Logger.log("🎉 Google フォームが正常に自動生成されました！");
  Logger.log("==========================================================");
  Logger.log("【編集用URL (実行委員長が編集・確認する用)】");
  Logger.log(form.getEditUrl());
  Logger.log("----------------------------------------------------------");
  Logger.log("【回答用URL (生徒たちにLINEやプリントで配る公開用)】");
  Logger.log(form.getPublishedUrl());
  Logger.log("==========================================================");
}
