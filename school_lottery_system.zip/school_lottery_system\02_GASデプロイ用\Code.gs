/**
 * ==============================================================================
 * 📊 文化祭 抽選結果照会システム - ポータブル・マルチテナント・高セキュリティ版 (Code.gs)
 * ==============================================================================
 * 
 * 【超重要：Apps Script デプロイ手順】
 * 
 * 1. 【ファイルの作成】
 *    Google Apps Script エディタの左側メニュー「＋」ボタン（ファイルを追加）から、
 *    以下の5つの「HTML」ファイルを追加し、それぞれ名前を正確に合わせてコードを貼り付けてください。
 *    - `sales`
 *    - `dashboard`
 *    - `dashadmin`
 *    - `admin`
 *    - `index`
 * 
 * 2. 【新しいデプロイの作成】
 *    画面右上の「デプロイ」ボタン ＞「新しいデプロイ」をクリックします。
 *    - 種類の選択（歯車アイコン）: 「ウェブアプリ」を選択します。
 *    - 説明: 「文化祭販売照会システム」など（任意）
 *    - 次のユーザーとして実行: 「自分（あなたのGoogleアカウント）」を選択。
 *    - アクセスできるユーザー: 必ず「全員」を選択してください！
 *      （※「全員」にしても、パスワードとドメイン制限が機能するため安全です）
 * 
 * 3. 【アクセス承認】
 *    「デプロイ」をクリックすると、アクセス承認の画面が出ます。
 *    - 「アクセスを承認」をクリックし、ご自身のアカウントを選択します。
 *    - 「Google による検出が終わっていないアプリ」という警告画面が出た場合は、
 *      左下の「詳細」をクリックし、さらに「（安全ではないページ）に移動」をクリックして承認を完了させてください。
 * 
 * 4. 【URLのコピー】
 *    デプロイ完了画面に表示される「ウェブアプリのURL」をコピーして、ローカルソフトに入力してください。
 * 
 * ==============================================================================
 */

/**
 * スプレッドシートからシステム設定を取得する
 */
function getSystemSettings() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("Settings");
  
  var defaultRows = [
    ["SCHOOL_NAME", "デモ高等学校", "システムに表示する学校名"],
    ["ADMIN_PASSWORD", "admin123", "管理者画面・販売管理画面用パスワード"],
    ["VIEW_PASSWORD", "", "一般閲覧ダッシュボード用パスワード（空なら全員に公開）"],
    ["RESTRICTED_DOMAINS", "", "【任意設定】特定の学校用Googleアカウントのみにアクセスを制限したい場合に入力します（例: school.ed.jp）。よく分からない場合や学校用メールアドレスがない場合は【完全に空欄のまま】にしてください。空欄なら個人アカウントでも誰でも使えます（その場合はパスワード保護のみで保護されます）。"],
    ["JSON_FOLDER_ID", "", "results.jsonの保存先フォルダID（空ならスプレッドシートと同じフォルダ）"],
    ["MAX_WISHES", "6", "希望調査の最大希望数。フォーム自動作成スクリプトが作成する希望質問の数になります"],
    ["STUDENT_ID_REGEX", "^\\d{4}$", "生徒番号の入力バリデーション用正規表現（例: 半角数字4桁なら ^\\d{4}$、アルファベット混在なら ^[A-Za-z0-9]+$）"],
    ["STUDENT_ID_HELP", "半角数字4桁で入力してください（例: 0012, 1234）。", "フォーム自動作成時に表示される生徒番号 of 入力説明テキスト"],
    ["STUDENT_ID_CONVERSION", "A:10,B:11,C:12,D:13,E:14,F:15,G:16,H:17,I:18,J:19,K:20,L:21,M:22,N:23,O:24,P:25,Q:26,R:27,S:28,T:29,U:30,V:31,W:32,X:33,Y:34,Z:35", "生徒番号をソート・範囲比較するための文字置換ルール（文字:置換数字 をカンマ区切りで指定）"],
    ["INFO_SHOPS", "「店舗設定」シートに入力してください", "【入力案内】店舗ごとのクラス、食品名、価格、キャパ等の設定場所"],
    ["INFO_PASSWORDS", "「クラスパスワード」シートに入力してください", "【入力案内】クラス別のログインパスワードの設定場所"]
  ];

  if (!sheet) {
    sheet = ss.insertSheet("Settings");
    sheet.appendRow(["Key", "Value", "説明 (変更後はウェブアプリを更新してください)"]);
    for (var i = 0; i < defaultRows.length; i++) {
      sheet.appendRow(defaultRows[i]);
    }
    sheet.getRange("A1:C1").setFontWeight("bold");
    sheet.setColumnWidth(1, 180);
    sheet.setColumnWidth(2, 250);
    sheet.setColumnWidth(3, 350);
  } else {
    // 既存のシートに欠けているキーがあれば追加する
    var lastRow = sheet.getLastRow();
    var keys = [];
    if (lastRow > 1) {
      keys = sheet.getRange(2, 1, lastRow - 1, 1).getValues().map(function(r) { return r[0].toString().trim(); });
    }
    for (var i = 0; i < defaultRows.length; i++) {
      if (keys.indexOf(defaultRows[i][0]) === -1) {
        sheet.appendRow(defaultRows[i]);
      }
    }
  }
  
  // 店舗設定シートもなければ自動生成
  var shopSheet = ss.getSheetByName("店舗設定");
  if (!shopSheet) {
    shopSheet = ss.insertSheet("店舗設定");
    shopSheet.appendRow(["クラス番号", "食品名", "販売キャパ（枚数）", "価格", "説明 (変更後はフォームを再作成してください)"]);
    shopSheet.appendRow(["3-A", "テスト商品1", "100", "300", "サンプル店舗1"]);
    shopSheet.appendRow(["3-B", "テスト商品2", "100", "350", "サンプル店舗2"]);
    shopSheet.getRange("A1:E1").setFontWeight("bold");
    shopSheet.setColumnWidth(1, 100);
    shopSheet.setColumnWidth(2, 150);
    shopSheet.setColumnWidth(3, 150);
    shopSheet.setColumnWidth(4, 100);
    shopSheet.setColumnWidth(5, 300);
    shopSheet.getRange("A:A").setNumberFormat("@");
  }
  
  // クラスパスワードシートもなければ自動生成
  getClassPasswords();

  var lastRow = sheet.getLastRow();
  if (lastRow <= 1) return {};
  
  var values = sheet.getRange(2, 1, lastRow - 1, 2).getValues();
  var settings = {};
  for (var i = 0; i < values.length; i++) {
    var k = values[i][0].toString().trim();
    var v = values[i][1].toString().trim();
    settings[k] = v;
  }
  return settings;
}

/**
 * フォルダから results.json ファイルを自動取得する
 */
function getResultsFile() {
  var settings = getSystemSettings();
  var folderId = settings["JSON_FOLDER_ID"];
  var folder;
  
  if (folderId) {
    folder = DriveApp.getFolderById(folderId);
  } else {
    var ssId = SpreadsheetApp.getActiveSpreadsheet().getId();
    var file = DriveApp.getFileById(ssId);
    var parents = file.getParents();
    if (parents.hasNext()) {
      folder = parents.next();
    } else {
      folder = DriveApp.getRootFolder();
    }
  }
  
  var files = folder.getFilesByName("results.json");
  if (files.hasNext()) {
    return files.next();
  } else {
    var emptyJson = JSON.stringify({});
    var newFile = folder.createFile("results.json", emptyJson, MimeType.PLAIN_TEXT);
    return newFile;
  }
}

/**
 * 販売記録保存用のシートを取得する
 */
function getSalesSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("販売状況");
  if (!sheet) {
    sheet = ss.insertSheet("販売状況");
    sheet.appendRow(["タイムスタンプ", "Key", "生徒番号", "クラス", "商品名"]);
    sheet.getRange("A1:E1").setFontWeight("bold");
  }
  return sheet;
}

/**
 * HTTP GETリクエスト時の処理 (画面の表示・ルーティング)
 */
function doGet(e) {
  var page = (e && e.parameter) ? (e.parameter.p || e.parameter.page) : null;
  var template;
  
  if (page === 'admin') {
    template = HtmlService.createTemplateFromFile('admin');
  } else if (page === 'dashadmin') {
    template = HtmlService.createTemplateFromFile('dashadmin');
  } else if (page === 'dashboard') {
    template = HtmlService.createTemplateFromFile('dashboard');
  } else {
    template = HtmlService.createTemplateFromFile('sales');
  }
  
  // HTMLテンプレートに動的にページのタイプを設定
  template.pageType = page || 'sales';
  
  return template.evaluate()
    .setTitle(page === 'dashboard' ? 'クラス用ダッシュボード' : (page === 'admin' ? '【管理者用】抽選結果照会' : (page === 'dashadmin' ? '【管理者用】総合ダッシュボード' : '食品販売本人確認・購入管理')))
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

/**
 * パスワード検証API
 */
function verifyPassword(password, pageType) {
  var settings = getSystemSettings();
  var expectedPassword = "";
  
  if (pageType === 'dashboard') {
    expectedPassword = settings["VIEW_PASSWORD"];
    // 閲覧パスワードが未設定の場合は、検証なしで常に成功
    if (!expectedPassword) return true;
  } else {
    expectedPassword = settings["ADMIN_PASSWORD"] || "admin123";
  }
  
  return password === expectedPassword;
}

/**
 * アクセス制限チェックAPI（ドメイン制限及びパスワード制限有無の通知）
 */
function checkAccess(pageType) {
  var settings = getSystemSettings();
  
  // 1. ドメイン制限の検証
  var restrictedStr = settings["RESTRICTED_DOMAINS"];
  if (restrictedStr) {
    var email = Session.getActiveUser().getEmail();
    if (!email) {
      return {
        allowed: false,
        reason: "domain_restriction",
        message: "このシステムにアクセスするには、Googleアカウント（個人のものでも学校のものでも可）へのログインが必要です。\n\n【解決方法】\n右上またはブラウザの設定からアカウントにログインし、ページを再読み込みしてください。"
      };
    }
    
    var domain = email.split("@")[1].toLowerCase();
    var allowedDomains = restrictedStr.split(",").map(function(d) { return d.trim().toLowerCase(); });
    
    var domainAllowed = false;
    for (var i = 0; i < allowedDomains.length; i++) {
      var allowed = allowedDomains[i];
      if (allowed.indexOf("*") === 0) {
        var suffix = allowed.substring(1); // "*.ed.jp" -> ".ed.jp"
        if (domain.slice(-suffix.length) === suffix) {
          domainAllowed = true;
          break;
        }
      } else if (domain === allowed) {
        domainAllowed = true;
        break;
      }
    }
    
    if (!domainAllowed) {
      return {
        allowed: false,
        reason: "domain_restriction",
        message: "ログイン中のメールアドレス（" + email + "）からはアクセスが許可されていません。\n\n【解決方法】\n1. 学校アカウントをお持ちの場合は、学校のアカウント（Googleアカウント）に切り替えて再読み込みしてください。\n2. 学校アカウントがない場合、またはログイン制限を解除したい場合は、スプレッドシートの「Settings」シートを開き、「RESTRICTED_DOMAINS」のValue（設定値）欄を【完全に空欄】にしてから、ページを再読み込みしてください。"
      };
    }
  }
  
  // 2. パスワード制限の有無をクライアントに返す
  var hasPassword = false;
  if (pageType === 'dashboard') {
    hasPassword = !!settings["VIEW_PASSWORD"];
  } else {
    hasPassword = !!settings["ADMIN_PASSWORD"];
  }
  
  return {
    allowed: true,
    hasPassword: hasPassword,
    email: Session.getActiveUser().getEmail() || "Guest"
  };
}

/**
 * 照会用：抽選結果JSONデータの取得
 */
function getResultsData() {
  try {
    var file = getResultsFile();
    var content = file.getBlob().getDataAsString('UTF-8');
    var trimmed = content.trim();
    if (trimmed.charCodeAt(0) === 0xFEFF) {
      trimmed = trimmed.substring(1);
    }
    return JSON.parse(trimmed);
  } catch (e) {
    console.error("getResultsDataでエラー発生:", e.toString());
    throw new Error("抽選結果データの読み込み中にエラーが発生しました: " + e.toString());
  }
}

/**
 * 照会用：スプレッドシートから購入済みチケットの取得
 */
function getPurchasedTickets() {
  try {
    var sheet = getSalesSheet();
    var lastRow = sheet.getLastRow();
    if (lastRow <= 1) return [];
    
    var data = sheet.getRange(2, 2, lastRow - 1, 1).getValues();
    var tickets = [];
    for (var i = 0; i < data.length; i++) {
      var val = data[i][0].toString();
      if (val) {
        tickets.push(val);
      }
    }
    return tickets;
  } catch (e) {
    console.error("Error in getPurchasedTickets: " + e.toString());
    return [];
  }
}

/**
 * 照会用：購入済みチケットの保存
 */
function savePurchasedTickets(clientTickets) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(10000); // 最大10秒待機
    var sheet = getSalesSheet();
    var lastRow = sheet.getLastRow();
    
    var existingSet = new Set();
    if (lastRow > 1) {
      var data = sheet.getRange(2, 2, lastRow - 1, 1).getValues();
      for (var i = 0; i < data.length; i++) {
        var val = data[i][0].toString();
        if (val) existingSet.add(val);
      }
    }
    
    var newTickets = [];
    if (clientTickets && clientTickets.length > 0) {
      for (var i = 0; i < clientTickets.length; i++) {
        if (!existingSet.has(clientTickets[i])) {
          newTickets.push(clientTickets[i]);
          existingSet.add(clientTickets[i]);
        }
      }
    }
    
    if (newTickets.length > 0) {
      var nowStr = Utilities.formatDate(new Date(), "Asia/Tokyo", "yyyy-MM-dd HH:mm:ss");
      var values = newTickets.map(function(t) {
        var parts = t.split('_');
        var sid = parts[0] || "";
        var classId = parts[1] || "";
        var storeName = parts.slice(2).join('_') || "";
        return [nowStr, t, sid, classId, storeName];
      });
      
      sheet.getRange(lastRow + 1, 1, values.length, 5).setValues(values);
    }
    
    return Array.from(existingSet);
  } catch (e) {
    console.error("Error in savePurchasedTickets: " + e.toString());
    return null;
  } finally {
    lock.releaseLock();
  }
}

/**
 * 【トラブルシューティング用】強制的に権限承認ダイアログを出すためのダミー関数
 */
function forceAuth() {
  SpreadsheetApp.create("Dummy");
  DriveApp.getFiles();
}

/**
 * クラス別のパスワード一覧を取得する
 */
function getClassPasswords() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName("クラスパスワード");
  if (!sheet) {
    sheet = ss.insertSheet("クラスパスワード");
    sheet.appendRow(["クラス名", "パスワード", "説明"]);
    sheet.appendRow(["3-A", "test", "3-Aのログイン用パスワード"]);
    sheet.appendRow(["3-B", "test", "3-Bのログイン用パスワード"]);
    sheet.getRange("A1:C1").setFontWeight("bold");
    sheet.setColumnWidth(1, 100);
    sheet.setColumnWidth(2, 150);
    sheet.setColumnWidth(3, 250);
    sheet.getRange("A:A").setNumberFormat("@");
  }
  
  var lastRow = sheet.getLastRow();
  if (lastRow <= 1) return {};
  
  var values = sheet.getRange(2, 1, lastRow - 1, 2).getValues();
  var passwords = {};
  for (var i = 0; i < values.length; i++) {
    var c = values[i][0].toString().trim();
    var p = values[i][1].toString().trim();
    if (c && p) {
      passwords[c] = p;
    }
  }
  return passwords;
}

/**
 * HTTP POSTリクエスト時の処理 (APIアクションのハンドラ)
 */
function doPost(e) {
  var result;
  try {
    var param = JSON.parse(e.postData.contents);
    var action = param.action;
    var password = param.password;
    
    // 基本設定を取得
    var settings = getSystemSettings();
    
    // セキュリティ検証:
    // ADMIN_PASSWORDが設定されており、かつデフォルトの「admin123」でもない場合は、パスワードが一致することを確認する。
    // (初期セットアップ時は設定が未完了であるため、デフォルト値の場合はセットアップを受け入れ可能にする)
    var currentAdminPassword = settings["ADMIN_PASSWORD"] || "admin123";
    
    if (currentAdminPassword !== "admin123" && password !== currentAdminPassword) {
      return ContentService.createTextOutput(JSON.stringify({ success: false, error: "Unauthorized: Invalid admin password" }))
        .setMimeType(ContentService.MimeType.JSON);
    }
    
    if (action === "setup") {
      result = setupSystem(param.data);
    } else if (action === "get_responses") {
      result = getResponsesData();
    } else if (action === "upload_results") {
      result = saveResultsJson(param.data);
    } else {
      result = { success: false, error: "Invalid action: " + action };
    }
  } catch (err) {
    result = { success: false, error: "System error: " + err.toString() };
  }
  
  return ContentService.createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * 初期設定データをスプレッドシートに書き込む
 */
function setupSystem(data) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // 1. Settingsシートの初期構築・上書き
  var settingsSheet = ss.getSheetByName("Settings");
  if (!settingsSheet) {
    // getSystemSettings() を呼んで自動生成させる
    getSystemSettings();
    settingsSheet = ss.getSheetByName("Settings");
  }
  
  if (settingsSheet && data.settings) {
    var lastRow = settingsSheet.getLastRow();
    if (lastRow > 1) {
      var range = settingsSheet.getRange(2, 1, lastRow - 1, 2);
      var values = range.getValues();
      for (var i = 0; i < values.length; i++) {
        var key = values[i][0];
        if (data.settings[key] !== undefined) {
          values[i][1] = data.settings[key].toString();
        }
      }
      range.setValues(values);
    }
  }
  
  // 2. 店舗設定シートの初期構築・上書き
  var shopSheet = ss.getSheetByName("店舗設定");
  if (!shopSheet) {
    shopSheet = ss.insertSheet("店舗設定");
    shopSheet.appendRow(["クラス番号", "食品名", "販売キャパ（枚数）", "価格", "説明 (変更後はフォームを再作成してください)"]);
    shopSheet.getRange("A1:E1").setFontWeight("bold");
    shopSheet.setColumnWidth(1, 100);
    shopSheet.setColumnWidth(2, 150);
    shopSheet.setColumnWidth(3, 150);
    shopSheet.setColumnWidth(4, 100);
    shopSheet.setColumnWidth(5, 300);
  }
  
  if (shopSheet && data.shops) {
    var lastRow = shopSheet.getLastRow();
    if (lastRow > 1) {
      shopSheet.deleteRows(2, lastRow - 1);
    }
    for (var i = 0; i < data.shops.length; i++) {
      var s = data.shops[i];
      shopSheet.appendRow([
        s.class_id || "", 
        s.store_name || "", 
        s.ticket_count !== undefined ? s.ticket_count.toString() : "0", 
        s.price !== undefined ? s.price.toString() : "0", 
        s.description || ""
      ]);
    }
    shopSheet.getRange("A:A").setNumberFormat("@");
  }
  
  // 3. クラスパスワードシートの初期構築・上書き
  var pwdSheet = ss.getSheetByName("クラスパスワード");
  if (!pwdSheet) {
    pwdSheet = ss.insertSheet("クラスパスワード");
    pwdSheet.appendRow(["クラス名", "パスワード", "説明"]);
    pwdSheet.getRange("A1:C1").setFontWeight("bold");
    pwdSheet.setColumnWidth(1, 100);
    pwdSheet.setColumnWidth(2, 150);
    pwdSheet.setColumnWidth(3, 250);
  }
  
  if (pwdSheet && data.passwords) {
    var lastRow = pwdSheet.getLastRow();
    if (lastRow > 1) {
      pwdSheet.deleteRows(2, lastRow - 1);
    }
    for (var i = 0; i < data.passwords.length; i++) {
      var p = data.passwords[i];
      pwdSheet.appendRow([
        p.class_id || "", 
        p.password || "", 
        p.description || ""
      ]);
    }
    pwdSheet.getRange("A:A").setNumberFormat("@");
  }
  
  return { success: true };
}

/**
 * 抽選応募データをスプレッドシートから抽出する
 */
function getResponsesData() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheets = ss.getSheets();
  var responseSheet = null;
  
  // 1行目のA列に「タイムスタンプ」が含まれるシートを自動で探す
  for (var i = 0; i < sheets.length; i++) {
    if (sheets[i].getLastRow() > 0) {
      var firstCellVal = sheets[i].getRange(1, 1).getValue().toString();
      if (firstCellVal.indexOf("タイムスタンプ") !== -1) {
        responseSheet = sheets[i];
        break;
      }
    }
  }
  
  if (!responseSheet) {
    return { success: false, error: "Googleフォームの回答データ（「タイムスタンプ」列から始まるシート）が見つかりません。" };
  }
  
  var values = responseSheet.getDataRange().getValues();
  // すべてのデータを文字列化して安全に転送
  var stringData = values.map(function(row) {
    return row.map(function(cell) {
      if (cell instanceof Date) {
        return Utilities.formatDate(cell, "Asia/Tokyo", "yyyy-MM-dd HH:mm:ss");
      }
      return cell.toString();
    });
  });
  
  return { success: true, data: stringData };
}

/**
 * 抽選結果JSONをGoogleドライブに保存する
 */
function saveResultsJson(jsonData) {
  var file = getResultsFile();
  file.setContent(JSON.stringify(jsonData, null, 2));
  return { success: true };
}


