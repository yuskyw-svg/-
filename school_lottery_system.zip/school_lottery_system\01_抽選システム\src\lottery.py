"""
lottery.py
抽選エンジンモジュール。
数理最適化（OR-Tools CP-SAT）と局所探索（Local Search）を用いた
文化祭食券抽選の全体最適化アルゴリズム。
"""

import random
import os
import json
import copy
from datetime import datetime
from collections import Counter
from ortools.sat.python import cp_model

class Shop:
    """店舗データクラス"""

    def __init__(self, name: str, class_id: str, store_name: str, ticket_count: int, ticket_price: int = 0):
        self.name = name              # 店舗ラベル（例: "A"）
        self.class_id = class_id      # クラス番号（例: "3-1"）
        self.store_name = store_name  # 食品名（例: "焼きそば"）
        self.ticket_count = ticket_count  # 食券枚数
        self.ticket_price = ticket_price  # 価格

    @property
    def display_name(self) -> str:
        """表示用名称 例: A (3-1 焼きそば)"""
        return f"{self.name} ({self.class_id} {self.store_name})"


def calculate_evaluation(assignment, student_wishes, menu_capacities, students_info, class_shops):
    """
    現在の割り当てに対する厳密な評価値を計算する。
    
    評価値 = (当選した生徒数 * 100000) + 総満足度スコア
    ※ 未当選者を減らすことが最優先。その上で、希望順位の高いものが選ばれるようにする。
    """
    total_students = len(students_info)
    menu_counts = Counter()

    score_mapping = {1: 6, 2: 5, 3: 4, 4: 3, 5: 2, 6: 1, 7: 1}
    total_satisfaction_score = 0
    zero_ticket_count = 0
    is_valid = True

    for s in students_info:
        sid = s['id']
        wishes = student_wishes[sid]
        assigned = assignment.get(sid, [])
        assigned_count = len(assigned)

        if assigned_count == 0:
            zero_ticket_count += 1

        # クラスごとの当選数チェック用
        class_wins = Counter()

        for m in assigned:
            menu_counts[m] += 1
            if m in wishes:
                rank = wishes.index(m) + 1
                total_satisfaction_score += score_mapping.get(rank, 1)
            else:
                is_valid = False # 希望していないものが割り当てられている

            # クラスごとの制限：1クラスあたり最大2個まで当選可
            for class_id, shop_labels in class_shops.items():
                if m in shop_labels:
                    class_wins[class_id] += 1

        # 同一クラスから3つ以上当選していたら無効
        if any(count > 2 for count in class_wins.values()):
            is_valid = False

    # メニューの販売上限超過チェック
    for m, count in menu_counts.items():
        if count > menu_capacities.get(m, 0):
            is_valid = False

    if not is_valid:
        return -99999999, zero_ticket_count, 0

    evaluation_value = (total_students - zero_ticket_count) * 100000 + total_satisfaction_score
    avg_score = total_satisfaction_score / total_students if total_students > 0 else 0

    return evaluation_value, zero_ticket_count, avg_score


def run_lottery(shops: list, students: dict, base_dir: str, iterations: int = 1000, max_time_seconds: float = 20.0, max_valid_wish_rank: int = 7, log_callback=None) -> str:
    """
    数理最適化 (CP-SAT) と局所探索 (Local Search) を用いて抽選を実行する。
    """
    # ログ出力用ヘルパー
    log_lines = []
    def log(msg):
        log_lines.append(msg)
        if log_callback:
            log_callback(msg)

    log("=== 抽選開始 ===")
    log(f"生徒数: {len(students)}人、店舗数: {len(shops)}店")

    # 結果ディレクトリの準備
    results_dir = os.path.join(base_dir, "result")
    os.makedirs(results_dir, exist_ok=True)

    # 各種マッピングの構築
    menu_list = [shop.name for shop in shops]
    menu_capacities = {shop.name: shop.ticket_count for shop in shops}
    
    # 柔軟な店舗マッピング用辞書の構築 (すべて大文字で比較)
    shop_mapping = {}
    for shop in shops:
        label_upper = shop.name.strip().upper()  # 例: "A"
        store_upper = shop.store_name.strip().upper()  # 例: "クロッフル"
        class_upper = shop.class_id.strip().upper()  # 例: "3-1"
        
        # 1. 店舗記号そのもの (例: "A" -> "A")
        shop_mapping[label_upper] = label_upper
        
        # 2. 食品名そのもの (例: "クロッフル" -> "A")
        if store_upper:
            if store_upper in shop_mapping and shop_mapping[store_upper] != label_upper:
                log(f"警告: 食品名 '{shop.store_name}' が複数のクラスで重複しています。重複がある場合は、回答CSVに店舗記号またはクラス名が必要になる場合があります。最初の店舗 '{shop_mapping[store_upper]}' に一時マッピングされます。")
            else:
                shop_mapping[store_upper] = label_upper
                
        # 3. クラス名_食品名 (例: "3-1_クロッフル" -> "A")
        if class_upper and store_upper:
            combined = f"{class_upper}_{store_upper}"
            shop_mapping[combined] = label_upper
            
            # スペース区切りも考慮 (例: "3-1 クロッフル" -> "A")
            combined_space = f"{class_upper} {store_upper}"
            shop_mapping[combined_space] = label_upper

    # クラスごとの店舗マッピング
    class_shops = {}
    for shop in shops:
        if shop.class_id not in class_shops:
            class_shops[shop.class_id] = []
        class_shops[shop.class_id].append(shop.name)

    # 生徒情報の前処理
    students_info = []
    student_wishes = {}

    for sid, data in students.items():
        name = data["name"]
        raw_wishes = data["wishes"]

        # 有効な希望のみを抽出（店舗ラベル、食品名、クラス名_食品名にマッピング）
        wishes = []
        for idx, w in enumerate(raw_wishes):
            if idx >= max_valid_wish_rank:
                break
            w_clean = w.strip().upper()
            if w_clean in shop_mapping:
                wishes.append(shop_mapping[w_clean])

        wish_count = len(wishes)
        student_wishes[sid] = wishes

        # 天井枚数の設定
        if wish_count <= 4:
            max_tickets = 2
        else:
            max_tickets = 4

        students_info.append({
            'id': sid,
            'name': name,
            'wish_count': wish_count,
            'max_tickets': max_tickets
        })

    # --------------------------------------------------
    # Step 1: 数理最適化（OR-Tools CP-SAT）による初期探索
    # --------------------------------------------------
    log("\n--- Step 1: 数理最適化ソルバーによる初期探索を開始します ---")
    
    model = cp_model.CpModel()

    # 決定変数 x[s, m]: 生徒 s にメニュー m を割り当てる(1)か否か(0)
    x = {}
    for s in students_info:
        sid = s['id']
        for m in menu_list:
            if m in student_wishes[sid]:
                x[sid, m] = model.NewBoolVar(f'x_{sid}_{m}')
            else:
                x[sid, m] = 0

    # 制約①: 各メニューの販売上限数を厳守
    for m in menu_list:
        model.Add(sum(x[s['id'], m] for s in students_info if m in student_wishes[s['id']]) <= menu_capacities[m])

    # 制約②: 生徒ごとの最大当選枚数（天井）を制限
    for s in students_info:
        sid = s['id']
        model.Add(sum(x[sid, m] for m in menu_list if m in student_wishes[sid]) <= s['max_tickets'])

    # 制約③: 同一クラスからの当選上限（最大2つまで）
    for s in students_info:
        sid = s['id']
        for class_id, shop_labels in class_shops.items():
            relevant_vars = [x[sid, m] for m in shop_labels if m in student_wishes[sid]]
            if relevant_vars:
                model.Add(sum(relevant_vars) <= 2)

    # 補助変数: 各生徒が「最低1枚当たっているか（1）」を表す変数 y[s]
    y = {}
    for s in students_info:
        sid = s['id']
        y[sid] = model.NewBoolVar(f'y_{sid}')
        total_tickets = sum(x[sid, m] for m in menu_list if m in student_wishes[sid])
        model.Add(total_tickets >= y[sid])
        model.Add(total_tickets <= y[sid] * s['max_tickets'])

    # 目的関数
    objective_terms = []
    # 最優先：全員に最低1枚行き渡らせる
    for s in students_info:
        objective_terms.append(y[s['id']] * 10000)

    # 次優先：同条件内の偏りを防ぐためのランダム重み付き希望優先
    for s in students_info:
        for m in menu_list:
            if m in student_wishes[s['id']]:
                objective_terms.append(x[s['id'], m] * random.randint(1, 10))

    model.Maximize(sum(objective_terms))

    # ソルバーの実行
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = float(max_time_seconds)

    status = solver.Solve(model)

    current_assignment = {s['id']: [] for s in students_info}
    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        for s in students_info:
            sid = s['id']
            for m in menu_list:
                if m in student_wishes[sid] and solver.Value(x[sid, m]) == 1:
                    current_assignment[sid].append(m)
        log("初期探索で有効な解が見つかりました。")
    else:
        log("警告: 初期探索で有効な解が見つかりませんでした。空の割り当てから局所探索を開始します。")

    init_eval, init_zero, init_avg = calculate_evaluation(current_assignment, student_wishes, menu_capacities, students_info, class_shops)
    log(f"初期探索完了 -> 評価値: {init_eval} | 未当選者: {init_zero}人 | 平均スコア: {init_avg:.2f}点")

    # --------------------------------------------------
    # Step 2: 局所探索（Local Search）による全体最適化
    # --------------------------------------------------
    log(f"\n--- Step 2: 局所探索（Local Search）を {iterations} 回実行します ---")

    best_assignment = copy.deepcopy(current_assignment)
    best_eval = init_eval
    best_zero = init_zero
    best_avg = init_avg

    if iterations > 0:
        for i in range(1, iterations + 1):
            working_assignment = copy.deepcopy(best_assignment)

            # 操作A/B: チケットの交換・スワップ
            if random.random() < 0.5:
                s1, s2 = random.sample(students_info, 2)
                w1 = working_assignment[s1['id']]
                w2 = working_assignment[s2['id']]
                if w1 and w2:
                    m1 = random.choice(w1)
                    m2 = random.choice(w2)
                    if (m2 in student_wishes[s1['id']]) and (m1 in student_wishes[s2['id']]) and (m1 != m2) and (m2 not in w1) and (m1 not in w2):
                        w1.remove(m1)
                        w1.append(m2)
                        w2.remove(m2)
                        w2.append(m1)
            else:
                s = random.choice(students_info)
                w = working_assignment[s['id']]
                current_counts = Counter(m for t in working_assignment.values() for m in t)
                if w:
                    m_remove = random.choice(w)
                    available_wishes = [m for m in student_wishes[s['id']] if m not in w]
                    if available_wishes:
                        m_add = random.choice(available_wishes)
                        if current_counts[m_add] < menu_capacities.get(m_add, 0):
                            w.remove(m_remove)
                            w.append(m_add)

            # 操作C: 売れ残りチケットの追加付与（限界突破）
            current_counts = Counter(m for t in working_assignment.values() for m in t)
            shuffled_menus = list(menu_list)
            random.shuffle(shuffled_menus)

            for m in shuffled_menus:
                while current_counts[m] < menu_capacities.get(m, 0):
                    candidates = [s for s in students_info if m in student_wishes[s['id']] and m not in working_assignment[s['id']]]
                    if not candidates:
                        break

                    candidates.sort(key=lambda s: len(working_assignment[s['id']]))
                    
                    assigned_flag = False
                    for target_student in candidates:
                        # 天井制限チェック
                        if len(working_assignment[target_student['id']]) >= target_student['max_tickets']:
                            continue
                            
                        # クラス制限チェック
                        target_shop = next((shop for shop in shops if shop.name == m), None)
                        if target_shop:
                            class_wins = sum(1 for wm in working_assignment[target_student['id']] 
                                             if any(shop.name == wm and shop.class_id == target_shop.class_id for shop in shops))
                            if class_wins >= 2:
                                continue
                        
                        # 条件を満たす生徒にアサイン
                        working_assignment[target_student['id']].append(m)
                        current_counts[m] += 1
                        assigned_flag = True
                        break
                    
                    if not assigned_flag:
                        # すべての候補者が制限（天井またはクラス上限）に達しているため、これ以上この店舗のチケットを割り当てられない
                        break

            # 評価値計算
            loop_eval, loop_zero, loop_avg = calculate_evaluation(working_assignment, student_wishes, menu_capacities, students_info, class_shops)

            if loop_eval > best_eval:
                best_assignment = copy.deepcopy(working_assignment)
                best_eval = loop_eval
                best_zero = loop_zero
                best_avg = loop_avg
                log(f"イテレーション {i}/{iterations} -> 🚀 [更新] 評価値: {best_eval} | 未当選: {best_zero}人 | 平均スコア: {best_avg:.2f}点")
            elif i % 100 == 0 or i == iterations:
                log(f"イテレーション {i}/{iterations} -> 📋 現在平均: {loop_avg:.2f}点 | ベスト平均: {best_avg:.2f}点")

    log("\n=== 探索完了 ===")
    log(f"最終評価値: {best_eval}")
    log(f"未当選者数: {best_zero}人")
    log(f"平均満足度スコア: {best_avg:.2f}点")

    # --------------------------------------------------
    # Step 3: 結果の保存と同期用JSON生成
    # --------------------------------------------------
    # 当選者から各店舗ごとの当選者リストを作成
    shop_winners = {m: set() for m in menu_list}
    for sid, assigned in best_assignment.items():
        for m in assigned:
            shop_winners[m].add(sid)

    # クラスごとの当選結果テキスト保存
    class_groups = {}
    for shop in shops:
        if shop.class_id not in class_groups:
            class_groups[shop.class_id] = []
        class_groups[shop.class_id].append(shop)

    for class_id, shops_in_class in sorted(class_groups.items()):
        result_path = os.path.join(results_dir, f"{class_id}.txt")
        with open(result_path, "w", encoding="utf-8") as f:
            f.write(f"クラス {class_id} 当選結果\n")
            f.write("=" * 30 + "\n\n")

            for shop in shops_in_class:
                winners = shop_winners.get(shop.name, set())
                sorted_winners = sorted(winners)

                f.write(f"【{shop.store_name}】({shop.name}店)\n")
                f.write(f"食券枚数: {shop.ticket_count}枚 / 当選: {len(sorted_winners)}人\n")
                if sorted_winners:
                    for sid in sorted_winners:
                        f.write(f"  {sid}\n")
                else:
                    f.write("  （当選者なし）\n")
                f.write("\n")
        log(f"結果保存: {result_path}")

    # ログファイルの保存
    log_text = "\n".join(log_lines)
    log_path = os.path.join(base_dir, "log.txt")
    with open(log_path, "w", encoding="utf-8") as f:
        f.write(log_text)

    # 照会システム用 JSON / JS 出力
    inquiry_results = {}
    shop_map = {shop.name: shop for shop in shops}

    for s in students_info:
        sid = s['id']
        name = s['name']
        assigned = best_assignment[sid]

        wins_list = []
        for m in assigned:
            shop = shop_map.get(m)
            if shop:
                wins_list.append({
                    "class_id": shop.class_id,
                    "store_name": shop.store_name,
                    "price": shop.ticket_price
                })

        base_sid = sid.split("_")[0]
        if base_sid not in inquiry_results:
            inquiry_results[base_sid] = {
                "name": name,
                "wins": wins_list,
                "duplicates": []
            }
        else:
            inquiry_results[base_sid]["duplicates"].append({
                "name": name,
                "wins": wins_list
            })

    # json/js ファイルの書き出し
    json_path = os.path.join(base_dir, "results.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(inquiry_results, f, ensure_ascii=False, indent=2)

    js_path = os.path.join(base_dir, "results.js")
    with open(js_path, "w", encoding="utf-8") as f:
        f.write("const RESULTS_DATA = ")
        json.dump(inquiry_results, f, ensure_ascii=False, indent=2)
        f.write(";")

    log(f"照会システム用データ保存: {json_path}")
    log(f"照会システム用データ(JS)保存: {js_path}")

    # 公開フォルダへの同期
    dest_dirs = ["admin", "index", "sales", "dashboard", "gas_deploy"]
    for dest in dest_dirs:
        dest_dir_path = os.path.join(base_dir, dest)
        if os.path.exists(dest_dir_path):
            dest_json_path = os.path.join(dest_dir_path, "results.json")
            with open(dest_json_path, "w", encoding="utf-8") as f:
                json.dump(inquiry_results, f, ensure_ascii=False, indent=2)
            dest_js_path = os.path.join(dest_dir_path, "results.js")
            with open(dest_js_path, "w", encoding="utf-8") as f:
                f.write("const RESULTS_DATA = ")
                json.dump(inquiry_results, f, ensure_ascii=False, indent=2)
                f.write(";")
            log(f"└─ 複製先自動同期 ({dest}): {dest_js_path}")

    return log_text


def sync_results_from_files(results_dir: str, shops: list, students: dict, base_dir: str) -> int:
    """
    result/ フォルダのテキストファイルを解析し、results.json を再生成する。
    """
    # sid ごとの当選店舗リストを再構築
    # {sid: set(shop_label)}
    reconstructed_wins = {}

    if not os.path.exists(results_dir):
        return 0

    # ショップ情報のマッピング作成 {ラベル: Shop}
    shop_map = {s.name: s for s in shops}

    # 各テキストファイルを読み込む
    import re
    # 正規表現で店舗ラベルを取得するためのパターン
    # 例: 【焼きそば】(A店) -> ラベルは A
    shop_pattern = re.compile(r"【.+】\((.+)店\)")
    sid_pattern = re.compile(r"^\s{2}(\d{4})$")

    for filename in os.listdir(results_dir):
        if not filename.endswith(".txt"):
            continue
        
        path = os.path.join(results_dir, filename)
        with open(path, "r", encoding="utf-8") as f:
            current_shop_label = None
            for line in f:
                # 店舗行の検出
                shop_match = shop_pattern.search(line)
                if shop_match:
                    current_shop_label = shop_match.group(1)
                    continue
                
                # 当選者ID行の検出
                if current_shop_label:
                    sid_match = sid_pattern.match(line)
                    if sid_match:
                        sid = sid_match.group(1)
                        if sid not in reconstructed_wins:
                            reconstructed_wins[sid] = set()
                        reconstructed_wins[sid].add(current_shop_label)

    # results.json を生成
    inquiry_results = {}
    for sid, data in students.items():
        name = data["name"]
        wins_list = []
        if sid in reconstructed_wins:
            for shop_label in reconstructed_wins[sid]:
                target_shop = shop_map.get(shop_label)
                if target_shop:
                    wins_list.append({
                        "class_id": target_shop.class_id,
                        "store_name": target_shop.store_name,
                        "price": target_shop.ticket_price
                    })
        
        base_sid = sid.split("_")[0]
        if base_sid not in inquiry_results:
            inquiry_results[base_sid] = {
                "name": name,
                "wins": wins_list,
                "duplicates": []
            }
        else:
            inquiry_results[base_sid]["duplicates"].append({
                "name": name,
                "wins": wins_list
            })

    json_path = os.path.join(base_dir, "results.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(inquiry_results, f, ensure_ascii=False, indent=2)

    # ローカルファイルでも開けるように JS 形式も出力
    js_path = os.path.join(base_dir, "results.js")
    with open(js_path, "w", encoding="utf-8") as f:
        f.write("const RESULTS_DATA = ")
        json.dump(inquiry_results, f, ensure_ascii=False, indent=2)
        f.write(";")

    # 各公開用フォルダにも自動同期（複製）
    dest_dirs = ["admin", "index", "sales", "dashboard"]
    for dest in dest_dirs:
        dest_dir_path = os.path.join(base_dir, dest)
        if os.path.exists(dest_dir_path):
            # JSONの複製
            dest_json_path = os.path.join(dest_dir_path, "results.json")
            with open(dest_json_path, "w", encoding="utf-8") as f:
                json.dump(inquiry_results, f, ensure_ascii=False, indent=2)
            # JSの複製
            dest_js_path = os.path.join(dest_dir_path, "results.js")
            with open(dest_js_path, "w", encoding="utf-8") as f:
                f.write("const RESULTS_DATA = ")
                json.dump(inquiry_results, f, ensure_ascii=False, indent=2)
                f.write(";")

    return len(reconstructed_wins)
