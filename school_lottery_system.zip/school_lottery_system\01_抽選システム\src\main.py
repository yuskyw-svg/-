"""
main.py
文化祭 食券抽選システム エントリポイント。
"""

import tkinter as tk
from gui import LotteryApp


def main():
    root = tk.Tk()
    app = LotteryApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
