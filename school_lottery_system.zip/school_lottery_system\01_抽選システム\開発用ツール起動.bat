﻿@rem 2>nul
@chcp 65001 > nul
@echo off
cd src
python main.py
pause
