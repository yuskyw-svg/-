const RESULTS_DATA = {
  "1101": {
    "name": "青山廉汰",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "1102": {
    "name": "伊藤佳香",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1103": {
    "name": "今田裕葉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1104": {
    "name": "大上優果",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1105": {
    "name": "大森愛来",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1107": {
    "name": "加納彩智",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "1108": {
    "name": "亀井義人",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1110": {
    "name": "木原郁真",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "1111": {
    "name": "倉橋空大",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "1112": {
    "name": "後藤つむぎ",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1114": {
    "name": "塩田紗良",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1115": {
    "name": "清水啓介",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1116": {
    "name": "下村彩恵",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1119": {
    "name": "田中俊介",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "1120": {
    "name": "田渕千尋",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1121": {
    "name": "力石結子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1122": {
    "name": "土原悠希",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1123": {
    "name": "永田理沙",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1124": {
    "name": "長野唯知花",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "1126": {
    "name": "長谷川駿",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1127": {
    "name": "林原和駈",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1129": {
    "name": "丸上南々花",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1130": {
    "name": "實綿花奈",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1131": {
    "name": "最上紗羽",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "1132": {
    "name": "森藤杏奈",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1133": {
    "name": "山岡采子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1134": {
    "name": "山肩初葵",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1135": {
    "name": "山田澄空",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "1201": {
    "name": "秋本悠貴",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "1202": {
    "name": "石川真椰",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1203": {
    "name": "一柳　彩葉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "1204": {
    "name": "井上茜",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1205": {
    "name": "入江蛍",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1206": {
    "name": "江頭美海",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1207": {
    "name": "太田結菜",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1208": {
    "name": "小川さやか",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1209": {
    "name": "片岡秀梧",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1210": {
    "name": "岸菜悠眞",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "1211": {
    "name": "木村日花稟",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1212": {
    "name": "新谷咲織",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1213": {
    "name": "田尻咲姫",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1215": {
    "name": "田中凜",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "1216": {
    "name": "富盛蘭",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1217": {
    "name": "奈尾翔馬",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1218": {
    "name": "中尾俊司",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1219": {
    "name": "中村咲稀",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "1220": {
    "name": "中森幾一",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1221": {
    "name": "秦莉依咲",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1222": {
    "name": "濱岡春日",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1224": {
    "name": "藤村義人",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "1225": {
    "name": "牧山拓海",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1226": {
    "name": "松田崇志",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1227": {
    "name": "三浦淳正",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1228": {
    "name": "宮本一展",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1229": {
    "name": "宮森佳穂",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "1230": {
    "name": "村上結々",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "1231": {
    "name": "森十和子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1232": {
    "name": "森下千輝",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1233": {
    "name": "山下烈雄",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1234": {
    "name": "山中優理香",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1235": {
    "name": "吉田かのん",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1301": {
    "name": "秋田梨希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1302": {
    "name": "板橋秀知",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1303": {
    "name": "茨木晴大",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1304": {
    "name": "江川陽莉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1305": {
    "name": "岡﨑諒大",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1306": {
    "name": "岡田和真",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1307": {
    "name": "奥田優希",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1308": {
    "name": "片岡優実",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "1309": {
    "name": "金子莉々",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "1310": {
    "name": "栗田雄太",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1311": {
    "name": "五反田薫",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1312": {
    "name": "小溝駿",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1313": {
    "name": "篠原優月",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1314": {
    "name": "柴田湊人",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1315": {
    "name": "下﨑雄世",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1316": {
    "name": "鈴木蒼汰",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1317": {
    "name": "竹下寛乃",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1319": {
    "name": "玉野小雪",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1320": {
    "name": "爲平彩春",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1321": {
    "name": "中岡苺",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1322": {
    "name": "中村颯杜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1323": {
    "name": "野々川由弥",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1324": {
    "name": "畠山慈人",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1325": {
    "name": "松本晃太朗",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1326": {
    "name": "三浦陽香",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1327": {
    "name": "溝岡明咲日",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1329": {
    "name": "森清郁",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "1330": {
    "name": "森下紗希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1331": {
    "name": "森光駈",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1332": {
    "name": "山内美織",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1333": {
    "name": "山口萌々子",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1334": {
    "name": "山城雪紘",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1335": {
    "name": "依藤優太",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1402": {
    "name": "安部叡徳",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1404": {
    "name": "荒平晴",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1405": {
    "name": "石田千彩",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1406": {
    "name": "今田篤志",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1407": {
    "name": "金川瑠杏",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "1408": {
    "name": "韓嘉依",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1409": {
    "name": "工藤詩織",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1410": {
    "name": "佐藤翔太郎",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1411": {
    "name": "清水迫尚樹",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1413": {
    "name": "髙橋佑輔",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "1414": {
    "name": "田中茉歩",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "1415": {
    "name": "谷村紘",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1416": {
    "name": "長南光咲",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1417": {
    "name": "仲程遥",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "1418": {
    "name": "仲間陸",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1419": {
    "name": "中村帆那",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "1420": {
    "name": "秦慎太朗",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "1421": {
    "name": "花戸栞",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "1422": {
    "name": "堀田未空",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "1423": {
    "name": "松本望",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1424": {
    "name": "水野明莉",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "1426": {
    "name": "南柚宇",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1428": {
    "name": "山縣一輝",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "1429": {
    "name": "山道美月",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "1430": {
    "name": "山下春真",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "1432": {
    "name": "行広光夏",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "1433": {
    "name": "吉田百花",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "1434": {
    "name": "𠮷本結真",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2101": {
    "name": "阿部詩春",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2102": {
    "name": "井原蒼陽",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2103": {
    "name": "植松美晴",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2104": {
    "name": "牛尾佳愛",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2105": {
    "name": "大鴻奏人",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2106": {
    "name": "岡快飛",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2107": {
    "name": "尾形美咲",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2108": {
    "name": "小倉真理",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2109": {
    "name": "勝田優那",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2110": {
    "name": "金子庵利",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "2111": {
    "name": "川西大智",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2112": {
    "name": "木原章徳",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2113": {
    "name": "久保乙葉",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "2114": {
    "name": "倉本健翔",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2115": {
    "name": "小坂勇貴",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2116": {
    "name": "兒玉紗愛",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2117": {
    "name": "西條真尋",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2118": {
    "name": "塩飽拓未",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2119": {
    "name": "竹本菜乃",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2121": {
    "name": "土屋智史",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2122": {
    "name": "時貞陽菜",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2123": {
    "name": "冨吉咲希",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2124": {
    "name": "鳥丸栞那",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "2126": {
    "name": "伴一樹",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2128": {
    "name": "藤﨑優衣",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2129": {
    "name": "松﨑萌",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2130": {
    "name": "松島伍希",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2131": {
    "name": "松元新",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2132": {
    "name": "三谷依織梨",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2133": {
    "name": "三野瑞季",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2134": {
    "name": "宮岡佳基",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2136": {
    "name": "森まおみ",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2137": {
    "name": "森田光咲",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2138": {
    "name": "山藤援",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2140": {
    "name": "吉田航",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2202": {
    "name": "畝綺恵良",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "2203": {
    "name": "畝本咲良",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2204": {
    "name": "梅本惺琉",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2205": {
    "name": "大上拓真",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2206": {
    "name": "大村真優",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2207": {
    "name": "尾形華萌",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2210": {
    "name": "折本蒼",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2211": {
    "name": "梶原竜成",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2213": {
    "name": "姜美嘉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2214": {
    "name": "久保爽馬",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2215": {
    "name": "髙延和桜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2216": {
    "name": "木本康太",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2217": {
    "name": "清水一誠",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2218": {
    "name": "鈴木梨衣奈",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "2219": {
    "name": "住田侑里香",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2220": {
    "name": "竹内彩葉",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2221": {
    "name": "樹野結",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2223": {
    "name": "友光莞太",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2224": {
    "name": "中原果菜子",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2225": {
    "name": "中村亘瑛",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2226": {
    "name": "中矢瑞希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "2227": {
    "name": "野村明生",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2229": {
    "name": "原田葵葉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2230": {
    "name": "平本朋己",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2231": {
    "name": "福原ゆり",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2232": {
    "name": "藤川証",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2233": {
    "name": "藤山優里",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2235": {
    "name": "丸谷律弥",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2236": {
    "name": "向井陸",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2238": {
    "name": "吉岡愛",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2239": {
    "name": "吉村萠音",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2240": {
    "name": "和田あさひ",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "2301": {
    "name": "青山朔士",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2302": {
    "name": "飽浦知幸",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2303": {
    "name": "板屋優子",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2304": {
    "name": "伊藤周丸",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2306": {
    "name": "内村陽香",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "2307": {
    "name": "尾川華",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2308": {
    "name": "香川未竜",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2309": {
    "name": "兼平満帆",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "2311": {
    "name": "木村優太",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2312": {
    "name": "菅家穂香",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2313": {
    "name": "厚井莉奈",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2314": {
    "name": "古志　仁人",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2316": {
    "name": "末永海乃",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2317": {
    "name": "末平佐介",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2318": {
    "name": "空久保湊",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2319": {
    "name": "髙橋綸",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2320": {
    "name": "田中明花寧",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2321": {
    "name": "仲程桜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2323": {
    "name": "二村茉緒",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2324": {
    "name": "野島柚希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2325": {
    "name": "平加優月",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2326": {
    "name": "ファンザーハン",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2327": {
    "name": "藤田真輝",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2328": {
    "name": "古屋潤",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2329": {
    "name": "堀江祐吾",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2330": {
    "name": "松岡良燈",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2332": {
    "name": "南琥太郎",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2333": {
    "name": "向山結貴",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2334": {
    "name": "森田瑛斗",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2335": {
    "name": "矢田貝杏璃",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2336": {
    "name": "山根古豊",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2337": {
    "name": "山本大雅",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2338": {
    "name": "行長倖乃",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2340": {
    "name": "吉村悠馬",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "2401": {
    "name": "入口寧心",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2402": {
    "name": "上田悠花",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2403": {
    "name": "扇由奈",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2404": {
    "name": "貝田彩音",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "2405": {
    "name": "金子結香",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2406": {
    "name": "川上夏紀",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2407": {
    "name": "川中悠生",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2409": {
    "name": "小谷秀太",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2410": {
    "name": "佐々木晴大",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2411": {
    "name": "島本斗陽",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "2412": {
    "name": "白石倫大",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2413": {
    "name": "菅原彩乃",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2414": {
    "name": "住田紗星",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2415": {
    "name": "瀬分大志",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2416": {
    "name": "髙田綜甫",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2417": {
    "name": "高橋岳大",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2418": {
    "name": "竹下想代加",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2419": {
    "name": "田中葵",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2420": {
    "name": "谷昱澎",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2421": {
    "name": "田村　稀唯",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2422": {
    "name": "常國優果",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2423": {
    "name": "堂河内実奈",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2424": {
    "name": "富吉勇斗",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "2425": {
    "name": "中西悠菜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "2426": {
    "name": "中野智瑛",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "2427": {
    "name": "長野晏己",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2428": {
    "name": "中村柚月",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2429": {
    "name": "西岡航",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "2430": {
    "name": "波多野　裕也",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "2432": {
    "name": "平山陽都",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2434": {
    "name": "物見亘",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "2435": {
    "name": "森釉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2436": {
    "name": "安田薫",
    "wins": [],
    "duplicates": []
  },
  "2437": {
    "name": "山内幸奈",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "2438": {
    "name": "山岡暁志",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "2439": {
    "name": "渡邊夏帆",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3101": {
    "name": "青山由依奈",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3102": {
    "name": "赤松知虎",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3103": {
    "name": "東禾怜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3104": {
    "name": "安藤結菜",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3105": {
    "name": "井掛あかり",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3106": {
    "name": "池田明香里",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3108": {
    "name": "伊藤夏樹",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3109": {
    "name": "井上悠",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3110": {
    "name": "上内悠愛",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3111": {
    "name": "岡田葵",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3112": {
    "name": "小田彩菜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3113": {
    "name": "角田遥",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3114": {
    "name": "川口紗菜",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3115": {
    "name": "河本晃喜",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3116": {
    "name": "栗栖歩夢",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3117": {
    "name": "後藤あやめ",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3118": {
    "name": "小西尊",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3119": {
    "name": "清水智裕",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3120": {
    "name": "菅田和花",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3121": {
    "name": "鈴木隆之介",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3122": {
    "name": "世良優衣華",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3123": {
    "name": "髙橋瑞",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3124": {
    "name": "武井雅和",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3125": {
    "name": "田中陽",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3127": {
    "name": "長田晃典",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3128": {
    "name": "西本美杜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3129": {
    "name": "延谷悠杜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3130": {
    "name": "原千紘",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3131": {
    "name": "久田凌也",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3132": {
    "name": "樋山琉美",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3133": {
    "name": "平田快璃",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3134": {
    "name": "福谷修一",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3135": {
    "name": "藤井真緒",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3137": {
    "name": "道上香蓮",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3138": {
    "name": "山口莉世",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3139": {
    "name": "山本千陽",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "3140": {
    "name": "吉元美遥",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3201": {
    "name": "青山瑞希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3202": {
    "name": "今清水咲季",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3203": {
    "name": "上田遥乃",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3204": {
    "name": "大坪叶実",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3205": {
    "name": "奥田祐",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3206": {
    "name": "小野葵衣",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3207": {
    "name": "加度幸誠",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3208": {
    "name": "門野光莉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "3209": {
    "name": "金指基正",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3210": {
    "name": "亀岡知世",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3211": {
    "name": "川野真由",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3212": {
    "name": "木村芹那",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3213": {
    "name": "黒田怜花",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3214": {
    "name": "黒星龍惺",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3215": {
    "name": "嵯峨根伸弥",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3216": {
    "name": "佐藤織羽",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3217": {
    "name": "重藤健太",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3219": {
    "name": "菅原駿太",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3221": {
    "name": "須納瀬匠",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3223": {
    "name": "竹山幸希",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3224": {
    "name": "田中泉帆",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3225": {
    "name": "冨田汐良",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3226": {
    "name": "中村陽介",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "3227": {
    "name": "鍋島唯恩",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3228": {
    "name": "野口晴紀",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3229": {
    "name": "林陽愛乃",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3230": {
    "name": "平山桃羽",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3231": {
    "name": "廣瀬朝陽",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3232": {
    "name": "福田実紅",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3233": {
    "name": "又吉里衣",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3234": {
    "name": "松田彩希",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3235": {
    "name": "水田悠斗",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3236": {
    "name": "南美宇",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3238": {
    "name": "棟久　覚",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3239": {
    "name": "山本一花",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3240": {
    "name": "横山梓実",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3301": {
    "name": "天川桃",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3302": {
    "name": "在永大河",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3303": {
    "name": "石原唯",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3304": {
    "name": "伊丹大貴",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3305": {
    "name": "伊藤知哉",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3308": {
    "name": "大下拓己",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3309": {
    "name": "大室花歩",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3310": {
    "name": "大森友貴",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3313": {
    "name": "喜多希光",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3314": {
    "name": "木下日葵",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3315": {
    "name": "河野麟太郎",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3316": {
    "name": "児玉紗和",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3317": {
    "name": "古毛堂吟",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3318": {
    "name": "齋藤玲奈",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3319": {
    "name": "堺理麻",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3322": {
    "name": "津江麗羽",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3323": {
    "name": "戸田翔太",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3325": {
    "name": "中島奈美",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3326": {
    "name": "中原実希",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3327": {
    "name": "西祐一郎",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3328": {
    "name": "西岡和奏",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3329": {
    "name": "橋本莉奈",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3330": {
    "name": "林美希",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3331": {
    "name": "樋口穂香",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "3332": {
    "name": "福田潤",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3334": {
    "name": "藤原倖那",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3335": {
    "name": "北條由麻",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3336": {
    "name": "丸山桃佳",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3337": {
    "name": "三好桃香",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "3338": {
    "name": "山木戸紗希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3339": {
    "name": "山中結姫乃",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3340": {
    "name": "山成惠利沙",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3401": {
    "name": "市林彩",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3403": {
    "name": "猪俣諒真",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3404": {
    "name": "岩﨑達也",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3405": {
    "name": "江川貴悠",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3408": {
    "name": "大塚結生",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3409": {
    "name": "香川智理",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "3410": {
    "name": "蕪尾翔太",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "3411": {
    "name": "加本凛羽",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "3412": {
    "name": "木倉令雄",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3413": {
    "name": "木村仁菜",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3414": {
    "name": "木元紗帆",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3415": {
    "name": "河野友三郎",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3416": {
    "name": "後藤明里",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3417": {
    "name": "小森巴菜",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "3418": {
    "name": "佐々木瑠那",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3419": {
    "name": "笹田心咲",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3420": {
    "name": "下栗嘉文",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3421": {
    "name": "白男川隼人",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3422": {
    "name": "砂川寧音",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3423": {
    "name": "武井莉乃",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3424": {
    "name": "長南侑希",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3425": {
    "name": "中村天音",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3426": {
    "name": "秦光莉",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3427": {
    "name": "畠山心実",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "3428": {
    "name": "蜂須賀えりな",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3429": {
    "name": "濱中望羽",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3430": {
    "name": "平田陽詩",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3431": {
    "name": "平原咲歩",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3433": {
    "name": "松浦慧昂",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3434": {
    "name": "丸山あすか",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "3435": {
    "name": "水野笑花",
    "wins": [],
    "duplicates": []
  },
  "3436": {
    "name": "南壮真",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3437": {
    "name": "宮﨑虹百",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "3440": {
    "name": "吉田皓紀",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4101": {
    "name": "石本乃愛",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "4104": {
    "name": "太田瑛士",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "4107": {
    "name": "鎌田薫",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4108": {
    "name": "桑原愛美",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4110": {
    "name": "小武家有生",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4111": {
    "name": "佐々木萌愛",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4113": {
    "name": "菅田南帆",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4114": {
    "name": "孫　詩棋",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4115": {
    "name": "竹本晃大",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "4116": {
    "name": "近廣柊羽",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4118": {
    "name": "豊田理桜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4119": {
    "name": "内藤栞",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4121": {
    "name": "中津愛菜",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4123": {
    "name": "野村悠月",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4124": {
    "name": "東出美怜",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4125": {
    "name": "平野凪音",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4129": {
    "name": "寶利虎太郎",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4130": {
    "name": "堀田奈音",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4133": {
    "name": "村上礼花",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "4135": {
    "name": "森脇弘智",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4136": {
    "name": "山領蒼大",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4201": {
    "name": "秋津衣子",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4202": {
    "name": "石橋ももこ",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4203": {
    "name": "沖段奈優",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4204": {
    "name": "小草みらい",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "4205": {
    "name": "椛山花菜子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "4206": {
    "name": "川岡陽貴",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4207": {
    "name": "河野颯真",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "4208": {
    "name": "川本千紘",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4209": {
    "name": "小谷真也",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4210": {
    "name": "兒玉和花",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4211": {
    "name": "近藤良弥",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4212": {
    "name": "澤原芽以",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4213": {
    "name": "篠﨑椋太",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4214": {
    "name": "篠原煌季",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "4215": {
    "name": "瀬戸健太",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4216": {
    "name": "髙橋もも子",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4217": {
    "name": "田坂柚菜",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4218": {
    "name": "豊田輝",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4219": {
    "name": "中村桜子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4221": {
    "name": "新谷咲",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4222": {
    "name": "西田陽人",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4224": {
    "name": "平山友都",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4225": {
    "name": "笛田菜々美",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4227": {
    "name": "藤田真央",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4228": {
    "name": "藤近結梨",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4229": {
    "name": "堀井煌太",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4230": {
    "name": "松尾美空",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4231": {
    "name": "松前美佐",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4232": {
    "name": "矢口陽大",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4233": {
    "name": "山崎瀬戸",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4235": {
    "name": "山中夏希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "4236": {
    "name": "横山朔也",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4303": {
    "name": "大下倖叶",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4305": {
    "name": "岡野愛結",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4306": {
    "name": "岡本照亮",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4307": {
    "name": "沖村紗奈",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "4308": {
    "name": "梶田紗菜",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4309": {
    "name": "梶原優莉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4310": {
    "name": "嘉新桃花",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4311": {
    "name": "神田未咲希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "4312": {
    "name": "桑野僚",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4313": {
    "name": "児玉篤洸",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "4314": {
    "name": "城山芽唯",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4315": {
    "name": "髙尾咲公",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4316": {
    "name": "高木真白",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4317": {
    "name": "髙橋一海",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "4318": {
    "name": "高橋茉央",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4319": {
    "name": "田村百花",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4320": {
    "name": "坪田愛未",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4321": {
    "name": "中尾玄司",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4322": {
    "name": "中本達水",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4324": {
    "name": "西谷朱里",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4325": {
    "name": "花谷すい",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4326": {
    "name": "林悠斗",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4327": {
    "name": "平彩七",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "4328": {
    "name": "廣野陽太",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4329": {
    "name": "福岡　莉華",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "4330": {
    "name": "本郷　希美",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4332": {
    "name": "増永育真",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "4333": {
    "name": "三浦貴弘",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4334": {
    "name": "満尾篤輝",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4335": {
    "name": "藥師寺就",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4401": {
    "name": "青木七美",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4402": {
    "name": "粟村遙斗",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "4403": {
    "name": "井川弘一朗",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "4404": {
    "name": "池田平馬",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4406": {
    "name": "今井十和子",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4407": {
    "name": "内田陽貴",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4408": {
    "name": "占部莉々香",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4409": {
    "name": "奥田拓途",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4410": {
    "name": "兼田莉羽",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4411": {
    "name": "亀若滉佑",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4412": {
    "name": "川平蒼介",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4413": {
    "name": "木原隆太",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4414": {
    "name": "桑原知秀",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4415": {
    "name": "河野春希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4418": {
    "name": "下﨑　湊史",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4419": {
    "name": "寺山華琳",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4420": {
    "name": "戸川和香",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4421": {
    "name": "富家愛莉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "4422": {
    "name": "鳥井暖果",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "4423": {
    "name": "中島 脩杜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4425": {
    "name": "畠山幸人",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4426": {
    "name": "福原佑基",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4427": {
    "name": "藤田真奈",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4429": {
    "name": "古矢寧々",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4430": {
    "name": "三阪莉夢",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4431": {
    "name": "三宅美葡子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4432": {
    "name": "村上真菜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4433": {
    "name": "元田貴仁",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4434": {
    "name": "山本茉奈",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "4435": {
    "name": "弓木美緒",
    "wins": [],
    "duplicates": []
  },
  "4436": {
    "name": "横畠蓮",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4502": {
    "name": "井川景太",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4504": {
    "name": "井原 美桜",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4505": {
    "name": "今井啓貴",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4506": {
    "name": "大久保仁",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4507": {
    "name": "大西昇",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4508": {
    "name": "沖本　彩蓮",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4510": {
    "name": "梶原志織",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4511": {
    "name": "川上紗英",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4512": {
    "name": "川辺理央佳",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4513": {
    "name": "川本航大",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4514": {
    "name": "岸本日太朗",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4517": {
    "name": "迫田和佳",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "4518": {
    "name": "佐々木理桜",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4519": {
    "name": "佐藤壮眞",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4520": {
    "name": "實森陽音",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4521": {
    "name": "妹尾一樹",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4522": {
    "name": "瀬々理愛",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4523": {
    "name": "高田美空",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4524": {
    "name": "高橋乃音",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4525": {
    "name": "高宮結衣",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4526": {
    "name": "長岡実咲",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4528": {
    "name": "中矢奈那実",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "4529": {
    "name": "中山スミレ",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4530": {
    "name": "服部耕生",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4532": {
    "name": "藤森一颯",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4533": {
    "name": "安永奈央",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4535": {
    "name": "吉田佳穂",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4536": {
    "name": "若狹芽佳",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4602": {
    "name": "井関知宏",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4605": {
    "name": "岩木理子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4606": {
    "name": "大川遼輔",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4607": {
    "name": "大畠うらら",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4608": {
    "name": "景山晄之",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "4609": {
    "name": "河村陽香",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4610": {
    "name": "菅太一",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4611": {
    "name": "久保美貴子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4612": {
    "name": "後藤理沙",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4613": {
    "name": "駒口莉子",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4614": {
    "name": "西條統悟",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4615": {
    "name": "笹谷さと",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4616": {
    "name": "清水天寧",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4617": {
    "name": "髙橋寧音",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4618": {
    "name": "竹安穂乃果",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "4620": {
    "name": "中村奏太",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4621": {
    "name": "西口　真嗣",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4622": {
    "name": "野村太暉",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4623": {
    "name": "野村由佳",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "4624": {
    "name": "則本一帆",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4625": {
    "name": "羽賀愛菜",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4627": {
    "name": "佛圓栞子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4628": {
    "name": "三木槙示郎",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4629": {
    "name": "水出侑",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4630": {
    "name": "柳田さくや",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "4631": {
    "name": "山﨑美桜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4632": {
    "name": "山原大知",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "4633": {
    "name": "山本莉優",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4634": {
    "name": "吉村俊志",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "4635": {
    "name": "吉村優希",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "4636": {
    "name": "吉本煌聖",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5101": {
    "name": "天野元喜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5102": {
    "name": "池田陽那乃",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5103": {
    "name": "池戸大智",
    "wins": [],
    "duplicates": []
  },
  "5104": {
    "name": "今榮紗希",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5105": {
    "name": "今岡虎希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5107": {
    "name": "大辻唯人",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "5108": {
    "name": "岡崎瑛生",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5111": {
    "name": "河田朋子",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5112": {
    "name": "木下玲",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5113": {
    "name": "岸本彩花",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5114": {
    "name": "木原心菜",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5115": {
    "name": "小石彩乃",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5116": {
    "name": "河内優人",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5117": {
    "name": "古賀潤",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5118": {
    "name": "笹田心優",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5119": {
    "name": "篠原健",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5121": {
    "name": "高垣海玖",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5122": {
    "name": "帶刀友里",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5125": {
    "name": "時枝央",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5127": {
    "name": "野中二菜",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5128": {
    "name": "半田瑞貴",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5129": {
    "name": "平野杜季朗",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5130": {
    "name": "松井利雅",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5131": {
    "name": "松島史侑",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5132": {
    "name": "松田志織",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5133": {
    "name": "向井涼悟",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5134": {
    "name": "向山朋希",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5135": {
    "name": "村上弥優",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5136": {
    "name": "野納駈",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5137": {
    "name": "山田晃輝",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5139": {
    "name": "吉村優輝",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5201": {
    "name": "青山陽翔",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5203": {
    "name": "猪塚博文",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "5204": {
    "name": "伊藤遼哉",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "5206": {
    "name": "梅田美波",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5209": {
    "name": "木村心花",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5210": {
    "name": "河久芙美",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5211": {
    "name": "神戸遥翔",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5212": {
    "name": "髙本芽依",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "5213": {
    "name": "是澤弓奈",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5214": {
    "name": "重田絢音",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5216": {
    "name": "高田玲汰",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5217": {
    "name": "竹岡聖良",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5218": {
    "name": "竹本陽偉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5220": {
    "name": "堂本愛実",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5223": {
    "name": "成川総獅",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5225": {
    "name": "沼田大輝",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5227": {
    "name": "花戸拓己",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5228": {
    "name": "林紘太",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5229": {
    "name": "平賀美結",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5231": {
    "name": "弘兼千裕",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "5234": {
    "name": "外田凪",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5235": {
    "name": "幹戸葵",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5236": {
    "name": "村上旺次郎",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5238": {
    "name": "山下香織",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5239": {
    "name": "山田一太",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5240": {
    "name": "𠮷村柚紀",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5301": {
    "name": "井上凌駕",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5302": {
    "name": "上田菜々美",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "5304": {
    "name": "尾茂　祐香",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5305": {
    "name": "影山和香",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5306": {
    "name": "笠見莉央",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5308": {
    "name": "國廣さくら",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5310": {
    "name": "齋藤亜実",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5311": {
    "name": "崎原詩織",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5313": {
    "name": "菅原澪",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5315": {
    "name": "髙野ひまり",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5317": {
    "name": "谷知優",
    "wins": [],
    "duplicates": []
  },
  "5318": {
    "name": "谷水望愛",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5319": {
    "name": "仲山琉陽",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "5320": {
    "name": "西村采夏",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5321": {
    "name": "羽白優月",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5323": {
    "name": "福冨莉子",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5324": {
    "name": "松本和馬",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5326": {
    "name": "水野玲",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5327": {
    "name": "水戸優月",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5328": {
    "name": "森凛子",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5329": {
    "name": "山本多桜",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5331": {
    "name": "吉村佳純",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5401": {
    "name": "板橋伸知",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5402": {
    "name": "伊藤成央",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5403": {
    "name": "植田鈴菜",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5404": {
    "name": "岡崎絢香",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5405": {
    "name": "北野美咲",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5406": {
    "name": "木下陽仁",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5408": {
    "name": "小池楓",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5410": {
    "name": "河野耀",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5411": {
    "name": "下森瑠奈",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "5414": {
    "name": "手塚輝希",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5415": {
    "name": "東方田馨",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5416": {
    "name": "戸光桜夕",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5417": {
    "name": "鳥井優希",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5419": {
    "name": "畠山紗瑛",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5420": {
    "name": "平田華暖",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5422": {
    "name": "法正顕隆",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5425": {
    "name": "宮本優歩",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5426": {
    "name": "盛川遥",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5427": {
    "name": "森木美音莉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "5428": {
    "name": "山岡大起",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5430": {
    "name": "山地乃愛",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5431": {
    "name": "山下優月",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5432": {
    "name": "龍光寺玲奈",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5501": {
    "name": "市川桜子",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5502": {
    "name": "市林美咲",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5503": {
    "name": "伊藤悠人",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5508": {
    "name": "潮奏寧",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "5509": {
    "name": "梅木亮汰",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5510": {
    "name": "江口結菜",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5511": {
    "name": "榎本優奏",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5514": {
    "name": "川端唯莉",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5515": {
    "name": "川本健心",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5517": {
    "name": "北原悠磨",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5519": {
    "name": "久保田龍",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5520": {
    "name": "定金晴佳",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5521": {
    "name": "塩形郁穂子",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5524": {
    "name": "垰裕太",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5525": {
    "name": "竹村陽斗",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "5526": {
    "name": "德丸ちよ",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5532": {
    "name": "廣井みらい",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5534": {
    "name": "福田湊一朗",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5535": {
    "name": "三坂耕太郎",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5538": {
    "name": "村山瑛太",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5540": {
    "name": "吉島正陽",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5602": {
    "name": "上原祐介",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5603": {
    "name": "浦上里桜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5606": {
    "name": "加藤葉愛",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5607": {
    "name": "河原明日美",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5608": {
    "name": "川本みこ",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5610": {
    "name": "小林芽依",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5613": {
    "name": "髙岡夕愛",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5614": {
    "name": "高橋笙",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5615": {
    "name": "髙見悠華",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "5616": {
    "name": "武田大和",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5617": {
    "name": "中津賢哉",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5618": {
    "name": "中本優花",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5619": {
    "name": "柳楽果歩",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "5620": {
    "name": "西岡花乃",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5621": {
    "name": "西村優那",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5622": {
    "name": "野間咲希",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5623": {
    "name": "秦明日香",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5624": {
    "name": "濱岡穂菓",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5626": {
    "name": "福永奨",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5628": {
    "name": "藤田睦人",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5629": {
    "name": "古江潤成",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5631": {
    "name": "正木涼葉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5633": {
    "name": "松尾優衣",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5634": {
    "name": "松嶋宏明",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "5636": {
    "name": "松原怜那",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "5637": {
    "name": "美吉優良",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "5640": {
    "name": "山下璃子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6101": {
    "name": "青山悠那",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6103": {
    "name": "稲田実穂",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6105": {
    "name": "榎蒼悟",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6106": {
    "name": "大町英大",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6108": {
    "name": "貫地谷結里",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6109": {
    "name": "木下由香梨",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6110": {
    "name": "藏重遥香",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6111": {
    "name": "倉重麗",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6113": {
    "name": "高畑凜音",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6114": {
    "name": "齊藤颯太",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6115": {
    "name": "佐久間悠貴",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6116": {
    "name": "佐藤悠斗",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6117": {
    "name": "澤結菜",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6118": {
    "name": "重見誠仁",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6119": {
    "name": "島谷悠生",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6120": {
    "name": "杉原緒音",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6123": {
    "name": "鳥居なつみ",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6124": {
    "name": "仁熊翼",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6125": {
    "name": "馬場祐太",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6127": {
    "name": "火室時貴",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6128": {
    "name": "松浦奏多",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6130": {
    "name": "松野光希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6131": {
    "name": "丸川侑真",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6132": {
    "name": "三原結稟",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6133": {
    "name": "宮河沙世子",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6135": {
    "name": "山本珠綺",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6136": {
    "name": "吉門日菜歩",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6137": {
    "name": "吉村董子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6201": {
    "name": "池本泰己",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6203": {
    "name": "糸永樹生",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6204": {
    "name": "今井花音",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6209": {
    "name": "岡田遥花",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6210": {
    "name": "小田喬大",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6211": {
    "name": "垣内優希",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "6215": {
    "name": "清野一華",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6216": {
    "name": "佐々木琉成",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6219": {
    "name": "田中楽",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6220": {
    "name": "唐下七碧",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6222": {
    "name": "中野然",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6223": {
    "name": "西村和真",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6224": {
    "name": "花田恭理",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6225": {
    "name": "花田心",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6227": {
    "name": "平野健太",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6229": {
    "name": "本城朱理",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6231": {
    "name": "三戸星奈",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6233": {
    "name": "宮木理世",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6235": {
    "name": "矢口愛結",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6237": {
    "name": "結城千右希",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6301": {
    "name": "東日向子",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6302": {
    "name": "阿部梨花子",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6303": {
    "name": "池田知紗希",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6304": {
    "name": "植吉倫",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6305": {
    "name": "大石玲衣",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6306": {
    "name": "大元和奏",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6307": {
    "name": "沖本健悟",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6308": {
    "name": "川原侑己",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6309": {
    "name": "倉井駿輔",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6310": {
    "name": "後藤央乃",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6311": {
    "name": "坂本初音",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6312": {
    "name": "佐藤ななみ",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6313": {
    "name": "篠本大希",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6315": {
    "name": "田中陽菜",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6316": {
    "name": "坪田悠希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6317": {
    "name": "寺田蕗",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6319": {
    "name": "傳明地紀美子",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6321": {
    "name": "中島亮幹",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6323": {
    "name": "長谷川美怜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6324": {
    "name": "昼田悟志",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6325": {
    "name": "福服凌",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6326": {
    "name": "堀田未桜",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6327": {
    "name": "町田慈実",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "6328": {
    "name": "三好瑛理南",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6329": {
    "name": "三好悠紀斗",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6330": {
    "name": "若狭奏汰",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6331": {
    "name": "割下紀子",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6402": {
    "name": "井川栞",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6403": {
    "name": "石倉奈直",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6404": {
    "name": "板垣吏紅",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "6405": {
    "name": "魚谷果帆",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6406": {
    "name": "岡海来",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6407": {
    "name": "沖山実央",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "6408": {
    "name": "小原和乃葉",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6410": {
    "name": "蒲原義明",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6411": {
    "name": "近藤大翔",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6412": {
    "name": "貞近奏太",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6413": {
    "name": "實森紫月",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6414": {
    "name": "田中悠翔",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6416": {
    "name": "友光壮良",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6418": {
    "name": "西村昊真",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6419": {
    "name": "長谷川心暖",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6423": {
    "name": "平川渚彩",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "カルピス",
        "price": 50
      }
    ],
    "duplicates": []
  },
  "6424": {
    "name": "牧芽咲",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6425": {
    "name": "溝兼康平",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6428": {
    "name": "山内碧佑子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6429": {
    "name": "湯川心絆",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6430": {
    "name": "脇彩莉",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6501": {
    "name": "青木旬",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6502": {
    "name": "朝倉愛結",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6504": {
    "name": "石岡蒼依",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6505": {
    "name": "伊藤駿之介",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6508": {
    "name": "大坪由希実",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "6509": {
    "name": "尾田結梨",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6510": {
    "name": "小山田理彩",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6511": {
    "name": "柏原愛唯",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6512": {
    "name": "片山佑月",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6513": {
    "name": "加藤聖也",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6514": {
    "name": "椛山日菜子",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6515": {
    "name": "賀谷知咲",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6516": {
    "name": "神原絆乃",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（イチゴ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6518": {
    "name": "倉永結梨",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6519": {
    "name": "小林香菜",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6520": {
    "name": "齊藤くらら",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6521": {
    "name": "末廣爽",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6522": {
    "name": "菅田芽依",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6523": {
    "name": "空久保結愛",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6525": {
    "name": "中岡夏希",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "6526": {
    "name": "中川悠",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6527": {
    "name": "中島千夏",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6528": {
    "name": "橋田紗羽",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6529": {
    "name": "半田早菜枝",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6530": {
    "name": "藤田堅",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6531": {
    "name": "藤村翔大",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "いちごみるく",
        "price": 50
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（ブルーハワイ）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6533": {
    "name": "前田恵吾",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6534": {
    "name": "光岡碧",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　チョコ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6535": {
    "name": "村賀天祐",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6536": {
    "name": "森本結子",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6537": {
    "name": "柳澤隼士",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6538": {
    "name": "山先あい花",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（きなこ）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6539": {
    "name": "脇菜月",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6540": {
    "name": "和田壮馬",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6601": {
    "name": "朝倉絆月",
    "wins": [
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6602": {
    "name": "天野月乃姫",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6603": {
    "name": "礒井晴菜",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6604": {
    "name": "稲葉音樹",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6605": {
    "name": "上神夕奈",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6608": {
    "name": "圓東優",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6609": {
    "name": "大山結真",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6610": {
    "name": "岡石心春",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6612": {
    "name": "岡本昊",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6614": {
    "name": "賀谷実咲",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6615": {
    "name": "木部絵麻",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスの実ソーダ",
        "price": 100
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6616": {
    "name": "久保伊澄",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6617": {
    "name": "児玉彩佳",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6620": {
    "name": "笹岡仁子",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6621": {
    "name": "貞森由宇",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6622": {
    "name": "清水隆弘",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6623": {
    "name": "菅太智",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6624": {
    "name": "杉原伊織",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "アイスボックスソーダ",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6625": {
    "name": "瀬川奏大",
    "wins": [
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6628": {
    "name": "高橋壱太",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      }
    ],
    "duplicates": []
  },
  "6629": {
    "name": "内藤ももこ",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6630": {
    "name": "中田杏奈",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "6632": {
    "name": "橋本澪奈",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "6633": {
    "name": "番本純生",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "6634": {
    "name": "平本聖衣名",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6635": {
    "name": "福本桜",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6638": {
    "name": "村田凛音",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "6639": {
    "name": "矢田悠真",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "9001": {
    "name": "澄川利之校長先生",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（チョコ）",
        "price": 250
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "9002": {
    "name": "小西大輔教頭先生",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "9003": {
    "name": "北岡先生",
    "wins": [
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "9004": {
    "name": "和田先生",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（抹茶）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "クリームソーダ（メロン）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（チョコ）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "9005": {
    "name": "佐々木先生",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（クリーム）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      }
    ],
    "duplicates": []
  },
  "9006": {
    "name": "西尾先生",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（アイス＆メープル）",
        "price": 250
      }
    ],
    "duplicates": []
  },
  "9007": {
    "name": "岡﨑先生（事務）",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "9008": {
    "name": "平林先生（事務）",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "9009": {
    "name": "帆足先生",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "チュロス（シュガー）",
        "price": 200
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "9010": {
    "name": "中籔先生",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "4-Mar",
        "store_name": "チーズハットグ",
        "price": 350
      },
      {
        "class_id": "6-Mar",
        "store_name": "コウサクのサクサクッ！からあげ",
        "price": 300
      },
      {
        "class_id": "6-Mar",
        "store_name": "i²ceクリームパフェ　バニラ",
        "price": 200
      }
    ],
    "duplicates": []
  },
  "9011": {
    "name": "松本先生",
    "wins": [
      {
        "class_id": "3-Mar",
        "store_name": "フライドポテト",
        "price": 150
      },
      {
        "class_id": "1-Mar",
        "store_name": "アイスコーヒー",
        "price": 100
      }
    ],
    "duplicates": []
  },
  "9012": {
    "name": "高森先生",
    "wins": [
      {
        "class_id": "2-Mar",
        "store_name": "揚げもみじ（こしあん）",
        "price": 200
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      }
    ],
    "duplicates": []
  },
  "9013": {
    "name": "藤沢先生",
    "wins": [
      {
        "class_id": "1-Mar",
        "store_name": "クロッフル（いちご）",
        "price": 250
      },
      {
        "class_id": "1-Mar",
        "store_name": "レモネード",
        "price": 100
      },
      {
        "class_id": "3-Mar",
        "store_name": "揚げたこ焼き（３個入）",
        "price": 150
      },
      {
        "class_id": "5-Mar",
        "store_name": "ＡＢＣスープ",
        "price": 150
      }
    ],
    "duplicates": []
  }
};