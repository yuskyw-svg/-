﻿@rem 2>nul
@chcp 65001 > nul
@echo off
echo ====================================================
echo   文化祭 抽選・販売管理システム セットアップ開始
echo ====================================================
echo.
echo これからブラウザを起動し、管理スプレッドシートのコピー作成画面を開きます。
echo.
echo 【手順】
echo 1. 画面が開いたら「コピーを作成」ボタンをクリックします。
echo 2. ご自身のGoogleドライブに管理用スプレッドシートがコピーされます。
echo 3. コピーされたスプレッドシートを使ってセットアップを進めてください。
echo.
pause
start https://docs.google.com/spreadsheets/d/1B71J5oG9r-l0hIec_tQ7pWb86q5bL3U4QW-OExS12sY/copy
