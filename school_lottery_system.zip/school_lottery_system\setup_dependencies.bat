﻿@rem 2>nul
@chcp 65001 > nul
@echo off
echo ortoolsのセットアップを行います...
python -m pip install --upgrade pip
python -m pip install ortools
pause
