"""
data_loader.py
GoogleフォームCSVの読み込みと生徒データの前処理を行うモジュール。
"""

import csv


def load_csv(filepath: str) -> dict:
    """
    GoogleフォームのCSVを読み込み、生徒データを返す。

    - 同じstudent_idが複数ある場合、最後の回答のみ有効
    - student_idは4桁文字列として正規化
    - 氏名は判定に使用しない

    対応フォーマット:
      3列: timestamp, student_id, name, choice1, choice2, choice3
      7列: timestamp, student_id, name, choice1〜choice7

    Args:
        filepath: CSVファイルのパス

    Returns:
        dict: {student_id(str): {"name": str, "wishes": [choice1,...,choice7]}}
    """
    students = {}

    with open(filepath, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        header = next(reader)  # ヘッダー行

        id_counters = {}  # {student_id: [name1, name2, ...]}

        for row in reader:
            if len(row) < 4:
                continue

            # タイムスタンプ(0), 生徒番号(1), 氏名(2), 希望(3〜)
            raw_student_id = row[1].strip()
            name = row[2].strip() if len(row) > 2 else ""

            # 生徒番号を4桁文字列に正規化
            student_id = raw_student_id.zfill(4)

            # 希望を取得（最大7つ）
            wishes = []
            for i in range(7):
                col_idx = 3 + i
                if col_idx < len(row):
                    val = row[col_idx].strip()
                    wishes.append(val if val else "none")
                else:
                    wishes.append("none")

            # 曖昧名前一致チェックのため、全角半角スペースを除去
            def normalize_name(n):
                return n.replace(" ", "").replace("　", "")
            
            name_norm = normalize_name(name)

            # 既に student_id が students に存在するかチェック
            found_existing_student = False
            key_candidates = [student_id]
            if student_id in id_counters:
                for idx in range(1, len(id_counters[student_id])):
                    key_candidates.append(f"{student_id}_dup{idx}")

            for k in key_candidates:
                if k in students:
                    if normalize_name(students[k]["name"]) == name_norm:
                        students[k]["wishes"] = wishes
                        found_existing_student = True
                        break

            if not found_existing_student:
                if student_id in students:
                    # 名前が異なる場合（別人の生徒番号重複登録）
                    if student_id not in id_counters:
                        id_counters[student_id] = [students[student_id]["name"]]
                    
                    dup_index = len(id_counters[student_id])
                    dup_key = f"{student_id}_dup{dup_index}"
                    students[dup_key] = {
                        "name": name,
                        "wishes": wishes,
                    }
                    id_counters[student_id].append(name)
                else:
                    # 新規登録
                    students[student_id] = {
                        "name": name,
                        "wishes": wishes,
                    }

    return students


def get_remaining_wishes(wishes: list) -> int:
    """
    希望数（noneでない希望の数）を返す。

    Args:
        wishes: [choice1, ..., choice7]

    Returns:
        int: none でない希望の数
    """
    count = 0
    for w in wishes:
        if w.lower() != "none" and w != "":
            count += 1
    return count
